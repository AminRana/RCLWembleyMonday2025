#Write a program to check and print whether it is a prime number or not.
#Hints: prime number can be divisible by the number itself and 1 only.
def prime(number):
    if number <= 1:
        return False
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            return False
    return True

# Take user input
usernumber = int(input("Enter a number: "))

# Check and print result
if prime(usernumber):
    print(f"{usernumber} is a prime number.")
else:
    print(f"{usernumber} is not a prime number.")