# Week 4 Write a program to iterate all characters of a string (one by one)
#using a for loop and check it is a vowel or not# Program to check vowels in a string

# Program to check vowels in a string
user_input = input("Enter a string: ")
vowels = "aeiouAEIOU"

print(f"Checking vowels in: '{user_input}'")
for character in user_input:
    if character in vowels:
        print(f"'{character}' is a vowel")
    else:
        print(f"'{character}' is not a vowel")