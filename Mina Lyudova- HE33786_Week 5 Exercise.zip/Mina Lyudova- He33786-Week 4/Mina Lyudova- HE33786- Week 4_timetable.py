#Write a program to create a timetable for a given number.
#For example, if 7 is typed as an input, the program
#will display 7×1=7, 7x2=14, 7x3=21, up to 7x10=70


usernumber = int(input("Enter a number: "))

print(f"\nMultiplication Table for {usernumber}:")
for x in range(1, 11):
    print(f"{usernumber} × {x} = {usernumber * x}")