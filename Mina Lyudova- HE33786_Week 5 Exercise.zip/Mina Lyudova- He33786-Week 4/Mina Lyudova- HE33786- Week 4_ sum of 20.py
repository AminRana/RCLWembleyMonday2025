#Write a program to add all even numbers up to 20.
#For example, the program will add 2, 4, 6, up to 20.

total = 0
number = 2
while number <= 20:
    total += number
    number += 2
print("The sum of all even numbers up to 20 is =", total)