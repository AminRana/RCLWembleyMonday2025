#3. Create a simple sales tracking application with at least staff name, total sales,
#yes/no (target met) columns. The multidimensional list may look like below:
#Ben 2600 Yes
#Bull 3000 No
#Jolly 3500 No
#Kal 3200 Yes
sales_data = [
    ["Ben", 2600, "Yes"],
    ["Bull", 3000, "No"],
    ["Jolly", 3500, "No"],
    ["Kal", 3200, "Yes"]
]

print("Name\tTotal Sales\tTarget Met")
for s in sales_data:
    print(f"{s[0]}\t{s[1]}\t\t{s[2]}")
