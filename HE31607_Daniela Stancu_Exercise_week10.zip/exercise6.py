#6. Create a home item listing program with at least item id, item name, type of the
#item, status, quantity and estimated price for each/average columns. The
#multidimensional list may look like below:
#1 TV Equipment Old 2 200
#2 Table Furniture New 1 350
#3 Microwave Equipment New 1 100
#4 Beds Furniture Old 3 100
#5 Plates Household Old 10 1

home_items = [
    [1, "TV", "Equipment", "Old", 2, 200],
    [2, "Table", "Furniture", "New", 1, 350],
    [3, "Microwave", "Equipment", "New", 1, 100],
    [4, "Beds", "Furniture", "Old", 3, 100],
    [5, "Plates", "Household", "Old", 10, 1]
]

print("ID\tItem\tType\t\tStatus\tQty\tPrice")
for item in home_items:
    print(f"{item[0]}\t{item[1]}\t{item[2]}\t{item[3]}\t{item[4]}\t{item[5]}")
