#2. Create a simple assignment tracking system where you should have at least
#student name, date, yes/no (for submission) and number of words columns. The
#multidimensional
#list may look like below:
#John 16/03/2025 Yes 3200
#Bob No 0
#Dolly No 0
#Henry 18/03/2025 Yes 2950
#Joy 19/03/2025 Yes 3100
assignments = [
    ["John", "16/03/2025", "Yes", 3200],
    ["Bob", "-", "No", 0],
    ["Dolly", "-", "No", 0],
    ["Henry", "18/03/2025", "Yes", 2950],
    ["Joy", "19/03/2025", "Yes", 3100]
]

print("Name\tDate\t\tSubmission\tWords")
for a in assignments:
    print(f"{a[0]}\t{a[1]}\t{a[2]}\t\t{a[3]}")
