#1. Create a simple salary calculation program where you should have at least staff
#name, hourly rate, weekly hours and total columns. The multidimensional
#list may look like below:
#Ram 12.50 30 375
#Helen 15.00 28 420
#Goald 13.25 40 530
#Bens 18.40 25 460
staff_salaries = [
    ["Ram", 12.50, 30, 12.50 * 30],
    ["Helen", 15.00, 28, 15.00 * 28],
    ["Goald", 13.25, 40, 13.25 * 40],
    ["Bens", 18.40, 25, 18.40 * 25]
]

print("Name\tHourly Rate\tWeekly Hours\tTotal")
for staff in staff_salaries:
    print(f"{staff[0]}\t{staff[1]}\t\t{staff[2]}\t\t{staff[3]}")
