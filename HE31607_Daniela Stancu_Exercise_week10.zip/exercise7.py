#7. Create a book tracking application with at least book id, title, type (hard copy or
#softcopy), author, year of edition and price columns. The multidimensional list may
#look like below:
#101 Introduction to Python Hardcopy Mizanur Rahman 2023 5.00
#102 Cyberhacking techniques Softcopy Unknown 2024 2.99
#103 Microprocessor Hardcopy Mizanur Rahman 2002 3.99
#104 Computer Science Hardcopy CGP Books 2023 11.03
#105 Python All-in-one hardcopy John C. Shovic 2024 25.83


books = [
    [101, "Introduction to Python", "Hardcopy", "Mizanur Rahman", 2023, 5.00],
    [102, "Cyberhacking techniques", "Softcopy", "Unknown", 2024, 2.99],
    [103, "Microprocessor", "Hardcopy", "Mizanur Rahman", 2002, 3.99],
    [104, "Computer Science", "Hardcopy", "CGP Books", 2023, 11.03],
    [105, "Python All-in-one", "Hardcopy", "John C. Shovic", 2024, 25.83]
]

print("ID\tTitle\t\t\t\tType\t\tAuthor\t\t\tYear\tPrice")
for b in books:
    print(f"{b[0]}\t{b[1]:<25}\t{b[2]:<10}\t{b[3]:<20}\t{b[4]}\t{b[5]}")
