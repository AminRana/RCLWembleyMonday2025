#4. Create a simple students’ register application with at least student name, arrival
#status (on time or late) and yes/no (with/without laptop) columns. The
#multidimensional list may look like below:
#Dili On time Yes
#Jack On time No
#Krist Late Yes
#Den On time Yes
attendance = [
    ["Dili", "On time", "Yes"],
    ["Jack", "On time", "No"],
    ["Krist", "Late", "Yes"],
    ["Den", "On time", "Yes"]
]

print("Name\tArrival\t\tLaptop")
for s in attendance:
    print(f"{s[0]}\t{s[1]}\t{s[2]}")
