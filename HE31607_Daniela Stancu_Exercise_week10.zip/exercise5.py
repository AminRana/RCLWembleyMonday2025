#5. Create a students’ performance tracking application with at least student name,
#time spent for study (hours), favourite and expected result columns. The
#multidimensional list may look like below:
#Mahid 4 Swimming Merit
#Belly 3 Social media Pass
#John 6 Web surfing Distinction
#Finn 2 Football Pass
performance = [
    ["Mahid", 4, "Swimming", "Merit"],
    ["Belly", 3, "Social media", "Pass"],
    ["John", 6, "Web surfing", "Distinction"],
    ["Finn", 2, "Football", "Pass"]
]

print("Name\tHours\tFavourite\t\tResult")
for p in performance:
    print(f"{p[0]}\t{p[1]}\t{p[2]}\t\t{p[3]}")
