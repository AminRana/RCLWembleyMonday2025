#exercise 12-Refractor week 4
#exercise 8 using function
def print_number_sequences(start, end, step, count_per_row):
    for row_start in range(start, end + 1, step):
        line = [str(row_start + offset) for offset in range(count_per_row)]
        print(" ".join(line))

# Example usage:
print_number_sequences(0, 100, 10, 4)
