#exercise 11-Refractor week 4
def print_multiplication_table(up_to):
    for i in range(1, up_to + 1):
        for j in range(1, up_to + 1):
            print(f"{i} × {j} = {i * j:<3}", end="\t")
        print()

# Example usage:
print_multiplication_table(10)
