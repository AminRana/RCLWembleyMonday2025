#exercise 3-Triangle and rectangle with stars
def draw_triangle(base):
    for i in range(1, base + 1):
        print("*" * i)

def draw_rectangle(base):
    print("*" * base)
    for _ in range(base - 2):
        print("*" + " " * (base - 2) + "*")
    print("*" * base)

draw_triangle(6)
draw_rectangle(10)
