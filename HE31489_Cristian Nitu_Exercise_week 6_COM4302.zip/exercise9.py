#exercise 9-Menu program from math operation

def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def mul(x, y):
    return x * y

def div(x, y):
    if y == 0:
        return "Error: Cannot divide by zero"
    return x / y

def calculator_menu():
    while True:
        print("\n🔢 MENU")
        print("1. Adding")
        print("2. Subtracting")
        print("3. Multiplying")
        print("4. Dividing")
        print("5. Quit")

        choice = input("Enter your choice (1–5): ")

        if choice == '5':
            print("👋 Goodbye!")
            break

        try:
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
        except ValueError:
            print("❗ Invalid input. Please enter numbers.")
            continue

        if choice == '1':
            print(f"✅ Result: {add(a, b)}")
        elif choice == '2':
            print(f"✅ Result: {sub(a, b)}")
        elif choice == '3':
            print(f"✅ Result: {mul(a, b)}")
        elif choice == '4':
            print(f"✅ Result: {div(a, b)}")
        else:
            print("❗ Invalid choice. Please select between 1 and 5.")

# 🔁 Start the menu program
calculator_menu()
