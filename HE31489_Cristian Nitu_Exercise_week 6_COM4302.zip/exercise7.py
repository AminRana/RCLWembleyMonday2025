#exercise 7-Students dictionary

students = {
    "Mizan": {"IT": 86, "Science": 69},
    "Ram": {"IT": 75, "Science": 46},
    "John": {"IT": 35, "Science": 50},
    "Ann": {"IT": 55, "Science": 76},
    "Chris": {"IT": 45, "Science": 65}
}

def display_marks():
    print("\n📘 Student Marks:")
    for name, subjects in students.items():
        subject_marks = ", ".join([f"{subject}: {mark}" for subject, mark in subjects.items()])
        print(f"{name}: {subject_marks}")

def total_marks(name):
    return sum(students.get(name, {}).values())

def calculate_grade(mark):
    if mark >= 70:
        return "A"
    elif mark >= 50:
        return "B"
    elif mark >= 40:
        return "C"
    else:
        return "Fail"

def search_student(name):
    return students.get(name, "Student not found")

# 🏁 Run the enhanced program
display_marks()

# Example: View specific student's total and grade
name_to_check = "Ram"
total = total_marks(name_to_check)
grade = calculate_grade(total)
print(f"\n{name_to_check}'s Total Marks: {total}, Grade: {grade}")
