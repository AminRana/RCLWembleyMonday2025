#exercise 5-Total, average, max from list
def analyze_numbers(nums):
    total = sum(nums)
    average = total / len(nums)
    maximum = max(nums)
    print(f"Total: {total}, Average: {average:.2f}, Max: {maximum}")

analyze_numbers([5, 9, 2, 7, 12])
