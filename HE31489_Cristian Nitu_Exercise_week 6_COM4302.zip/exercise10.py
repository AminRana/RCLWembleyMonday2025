#exercise 10-Student menu program
students = {
    "Mizan": {"IT": 86, "Science": 69},
    "Ram": {"IT": 75, "Science": 46},
    "John": {"IT": 35, "Science": 50},
    "Ann": {"IT": 55, "Science": 76},
    "Chris": {"IT": 45, "Science": 65}
}

def display_all_data():
    print("\n📘 All Students' Marks:")
    for name, subjects in students.items():
        marks = ", ".join([f"{sub}: {score}" for sub, score in subjects.items()])
        print(f"{name}: {marks}")

def display_grades():
    print("\n🎓 Student Grades:")
    for name, subjects in students.items():
        total = sum(subjects.values())
        grade = calculate_grade(total)
        print(f"{name}: Total={total}, Grade={grade}")

def calculate_grade(total):
    if total >= 140:
        return "A"
    elif total >= 100:
        return "B"
    elif total >= 80:
        return "C"
    else:
        return "Fail"

def search_student(name):
    student = students.get(name)
    if student:
        marks = ", ".join([f"{sub}: {score}" for sub, score in student.items()])
        total = sum(student.values())
        grade = calculate_grade(total)
        print(f"\n🔍 {name}: {marks} | Total={total}, Grade={grade}")
    else:
        print("\n❌ Student not found!")

def student_menu():
    while True:
        print("\n🔢 MENU")
        print("1. Display all student data")
        print("2. Display all grades")
        print("3. Search a student")
        print("4. Quit")

        choice = input("Choose an option (1–4): ").strip()

        if choice == '1':
            display_all_data()
        elif choice == '2':
            display_grades()
        elif choice == '3':
            name = input("Enter student name to search: ")
            search_student(name.title())  # Title-case to match dictionary keys
        elif choice == '4':
            print("👋 Program ended. Goodbye!")
            break
        else:
            print("❗ Invalid option. Try again.")

# 🏁 Run the menu
student_menu()
