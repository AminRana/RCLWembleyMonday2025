#exercise 6-List of fruits
fruits = ['apple', 'banana', 'cherry', 'date', 'elderberry', 'fig', 'grape', 'kiwi', 'lime', 'mango']

def print_fruits():
    print(fruits)

def count_characters():
    for fruit in fruits:
        print(f"{fruit}: {len(fruit)} characters")

def add_fruit(new_fruit):
    fruits.append(new_fruit)

print_fruits()
count_characters()
add_fruit("nectarine")
