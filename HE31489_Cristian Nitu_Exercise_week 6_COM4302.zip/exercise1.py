#exercise 1-Expand example1.py
def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def mul(x, y):
    return x * y

def div(x, y):
    return x / y if y != 0 else "Cannot divide by zero"

print(add(3, 4))
print(sub(7, 2))
print(mul(5, 6))
print(div(10, 2))
