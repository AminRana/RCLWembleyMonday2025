#exercise 8-Cumulative input with loop

def cumulative_sum():
    total = 0
    while True:
        try:
            num = int(input("Type your number: "))
            total += num
            print("Your total:", total)
            again = input("Will you run the program again (yes/no)? ").lower()
            if again != "yes":
                print("Program ended.")
                break
        except ValueError:
            print("Please enter a valid number.")

# Call the function
cumulative_sum()
