#exercise 4-Sum all digits of a number
def sum_digits(n):
    return sum(int(digit) for digit in str(n))

print(sum_digits(432))  # Output: 9
