#exercise 2-Count from 1 to 1- and 10 to 1
def count_up():
    for i in range(1, 11):
        print(i, end=" ")

def count_down():
    for i in range(10, 0, -1):
        print(i, end=" ")

count_up()
print()
count_down()
