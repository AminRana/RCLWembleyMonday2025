#!/usr/bin/env python3
"""
Python Knowledge Quiz Game
A menu-based quiz application with multiple choice questions
Author: Student Assignment
Date: June 2025
"""

import random
import time

class QuizGame:
    """
    Main class for the Python Knowledge Quiz Game
    Handles game logic, scoring, and user interaction
    """
    
    def __init__(self):
        """Initialize the quiz game with questions and settings"""
        # Game settings and variables
        self.player_name = ""           # String to store player's name
        self.current_score = 0          # Integer to track current score
        self.total_questions = 0        # Integer to count total questions asked
        self.correct_answers = 0        # Integer to count correct answers
        self.game_active = True         # Boolean to control game loop
        
        # List of dictionaries containing quiz questions
        # Each question has: question text, options list, correct answer index
        self.questions = [
            {
                "question": "What is the correct way to create a list in Python?",
                "options": ["list = (1, 2, 3)", "list = [1, 2, 3]", "list = {1, 2, 3}", "list = <1, 2, 3>"],
                "correct": 1
            },
            {
                "question": "Which keyword is used to define a function in Python?",
                "options": ["function", "def", "define", "func"],
                "correct": 1
            },
            {
                "question": "What does the len() function return?",
                "options": ["The last element", "The first element", "The length/size", "The type"],
                "correct": 2
            },
            {
                "question": "Which of the following is a mutable data type in Python?",
                "options": ["String", "Tuple", "List", "Integer"],
                "correct": 2
            },
            {
                "question": "What is the output of print(type([]))?",
                "options": ["<class 'tuple'>", "<class 'list'>", "<class 'dict'>", "<class 'set'>"],
                "correct": 1
            },
            {
                "question": "Which operator is used for exponentiation in Python?",
                "options": ["^", "**", "*", "exp()"],
                "correct": 1
            },
            {
                "question": "What does the range(5) function generate?",
                "options": ["1, 2, 3, 4, 5", "0, 1, 2, 3, 4", "0, 1, 2, 3, 4, 5", "1, 2, 3, 4"],
                "correct": 1
            },
            {
                "question": "Which statement is used to exit a loop prematurely?",
                "options": ["exit", "break", "stop", "end"],
                "correct": 1
            },
            {
                "question": "What is the correct syntax for a while loop?",
                "options": ["while (condition):", "while condition:", "while condition", "while: condition"],
                "correct": 1
            },
            {
                "question": "Which method adds an element to the end of a list?",
                "options": ["add()", "insert()", "append()", "push()"],
                "correct": 2
            }
        ]
    
    def display_welcome(self):
        """Display welcome message and game instructions"""
        print("=" * 50)
        print("🐍 WELCOME TO PYTHON KNOWLEDGE QUIZ GAME 🐍")
        print("=" * 50)
        print("\n📚 GAME INSTRUCTIONS:")
        print("• Answer 10 multiple choice questions about Python")
        print("• Each correct answer earns you 10 points")
        print("• Type the number (1-4) corresponding to your answer")
        print("• You can view your score and statistics anytime")
        print("• Good luck and have fun learning!")
        print("-" * 50)
    
    def get_player_name(self):
        """Get and validate player name input"""
        while True:  # Input validation loop
            name = input("\n👤 Please enter your name: ").strip()
            # Check if name is not empty and contains valid characters
            if name and name.replace(" ", "").isalpha():
                self.player_name = name.title()  # Capitalize first letters
                print(f"\n🎉 Welcome, {self.player_name}! Let's start the quiz!")
                break
            else:
                print("❌ Please enter a valid name (letters only)")
    
    def display_menu(self):
        """Display main menu options"""
        print(f"\n{'=' * 30}")
        print(f"📋 MAIN MENU - {self.player_name}")
        print(f"{'=' * 30}")
        print("1. 🎯 Start Quiz")
        print("2. 📊 View Statistics")
        print("3. 📝 Quiz Instructions")
        print("4. 🚪 Exit Game")
        print("-" * 30)
    
    def get_menu_choice(self):
        """Get and validate menu choice from user"""
        while True:  # Input validation loop
            try:
                choice = int(input("👉 Enter your choice (1-4): "))
                # Check if choice is within valid range
                if 1 <= choice <= 4:
                    return choice
                else:
                    print("❌ Please enter a number between 1 and 4")
            except ValueError:  # Handle non-integer input
                print("❌ Please enter a valid number")
    
    def start_quiz(self):
        """Main quiz function - handles the quiz flow"""
        print(f"\n🎯 STARTING QUIZ FOR {self.player_name}")
        print("=" * 40)
        
        # Reset quiz statistics for new game
        self.current_score = 0
        self.correct_answers = 0
        self.total_questions = len(self.questions)
        
        # Create a shuffled copy of questions for variety
        quiz_questions = self.questions.copy()
        random.shuffle(quiz_questions)
        
        # Loop through each question
        for i, question_data in enumerate(quiz_questions, 1):
            print(f"\n📝 Question {i}/{self.total_questions}")
            print("-" * 25)
            print(f"❓ {question_data['question']}")
            print()
            
            # Display answer options
            for j, option in enumerate(question_data['options'], 1):
                print(f"   {j}. {option}")
            
            # Get user's answer with validation
            user_answer = self.get_answer()
            
            # Check if answer is correct (convert to 0-based index)
            if user_answer - 1 == question_data['correct']:
                print("✅ Correct! Well done!")
                self.current_score += 10  # Award 10 points for correct answer
                self.correct_answers += 1
                time.sleep(1)  # Brief pause for user to see result
            else:
                correct_option = question_data['options'][question_data['correct']]
                print(f"❌ Incorrect. The correct answer was: {correct_option}")
                time.sleep(1.5)  # Longer pause to read correct answer
        
        # Display final results
        self.display_results()
    
    def get_answer(self):
        """Get and validate answer choice from user"""
        while True:  # Input validation loop
            try:
                answer = int(input("\n💭 Your answer (1-4): "))
                # Check if answer is within valid range
                if 1 <= answer <= 4:
                    return answer
                else:
                    print("❌ Please enter a number between 1 and 4")
            except ValueError:  # Handle non-integer input
                print("❌ Please enter a valid number")
    
    def display_results(self):
        """Display quiz results and performance analysis"""
        print("\n" + "=" * 40)
        print("🏆 QUIZ COMPLETED - FINAL RESULTS")
        print("=" * 40)
        
        # Calculate percentage score
        percentage = (self.correct_answers / self.total_questions) * 100
        
        print(f"👤 Player: {self.player_name}")
        print(f"📊 Score: {self.current_score} points")
        print(f"✅ Correct Answers: {self.correct_answers}/{self.total_questions}")
        print(f"📈 Percentage: {percentage:.1f}%")
        
        # Provide performance feedback based on score
        if percentage >= 90:
            print("🥇 Outstanding! You're a Python expert!")
        elif percentage >= 70:
            print("🥈 Great job! You have solid Python knowledge!")
        elif percentage >= 50:
            print("🥉 Good effort! Keep practicing to improve!")
        else:
            print("📚 Keep studying! Python mastery takes practice!")
        
        print("-" * 40)
        input("Press Enter to return to main menu...")
    
    def display_statistics(self):
        """Display current game statistics"""
        print(f"\n📊 STATISTICS FOR {self.player_name}")
        print("=" * 35)
        print(f"🎯 Current Score: {self.current_score} points")
        print(f"✅ Correct Answers: {self.correct_answers}")
        print(f"📝 Total Questions: {self.total_questions}")
        
        # Calculate and display percentage if quiz was attempted
        if self.total_questions > 0:
            percentage = (self.correct_answers / self.total_questions) * 100
            print(f"📈 Success Rate: {percentage:.1f}%")
        else:
            print("📈 Success Rate: No quiz attempted yet")
        
        print("-" * 35)
        input("Press Enter to return to main menu...")
    
    def display_instructions(self):
        """Display detailed game instructions"""
        print("\n📝 DETAILED QUIZ INSTRUCTIONS")
        print("=" * 40)
        print("🎯 OBJECTIVE:")
        print("   Test your Python programming knowledge")
        print("   with 10 multiple choice questions")
        print()
        print("🎮 HOW TO PLAY:")
        print("   1. Choose 'Start Quiz' from the main menu")
        print("   2. Read each question carefully")
        print("   3. Select your answer by typing 1, 2, 3, or 4")
        print("   4. View your results at the end")
        print()
        print("📊 SCORING SYSTEM:")
        print("   • Each correct answer = 10 points")
        print("   • Maximum possible score = 100 points")
        print("   • 90%+ = Outstanding")
        print("   • 70%+ = Great")
        print("   • 50%+ = Good")
        print()
        print("💡 TIPS:")
        print("   • Take your time to read questions")
        print("   • Think about Python syntax and concepts")
        print("   • Learn from incorrect answers")
        print("-" * 40)
        input("Press Enter to return to main menu...")
    
    def run_game(self):
        """Main game loop - controls the entire application flow"""
        self.display_welcome()
        self.get_player_name()
        
        # Main menu loop - continues until user chooses to exit
        while self.game_active:
            self.display_menu()
            choice = self.get_menu_choice()
            
            # Process user's menu choice using conditional statements
            if choice == 1:
                self.start_quiz()  # Start the quiz
            elif choice == 2:
                self.display_statistics()  # Show statistics
            elif choice == 3:
                self.display_instructions()  # Show instructions
            elif choice == 4:
                # Exit game with confirmation
                print(f"\n👋 Thank you for playing, {self.player_name}!")
                print("🐍 Keep learning Python! Goodbye!")
                self.game_active = False  # Exit main loop
            
            # Clear screen effect for better user experience
            if self.game_active:
                print("\n" * 2)


def main():
    """
    Main function to start the quiz game application
    Entry point of the program
    """
    try:
        # Create an instance of the QuizGame class
        game = QuizGame()
        # Start the game
        game.run_game()
    
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        print("\n\n🛑 Game interrupted. Thanks for playing!")
    except Exception as e:
        # Handle any unexpected errors
        print(f"\n❌ An error occurred: {e}")
        print("Please restart the game.")


# Program entry point - only run if this file is executed directly
if __name__ == "__main__":
    main()
