Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example8.py ====
Type basic salary of marketing staff: 4500
Type basic salary of sales staff: 2300
Total of Marketing with bonus:  4950.0
Total of Sales with bonus:  2760.0
Grand total of salary with bonus:  7710.0
