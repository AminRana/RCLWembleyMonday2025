Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example2.py ====
Type length of the rectangle:25
Type width of the rectangle:10
Type radius of the circle:10
Area of the rectangle:  250
Area of the circle:  314.0
