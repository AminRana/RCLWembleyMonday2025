Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example17.py ===
['apple', 'banana', 'cherry', 'mango', 'orange']
0 apple
1 banana
2 cherry
3 mango
4 orange
To do the same by using a for loop
1 apple
2 banana
3 cherry
4 mango
5 orange
