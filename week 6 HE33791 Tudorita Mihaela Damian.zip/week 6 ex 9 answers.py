Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example9.py ====
John 	 England 	 40
Dolly 	 England 	 30
Lee 	 Scotland 	 25
Ann 	 England 	 22
Ben 	 Scotland 	 35
Jolly 	 Wales  	 32
Type to search a name: dolly
Name:  Dolly  found
