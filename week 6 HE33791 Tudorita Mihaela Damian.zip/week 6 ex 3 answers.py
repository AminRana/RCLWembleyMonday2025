Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example3.py ====
Even numbers up to 20: 
0 2 4 6 8 10 12 14 16 18 20 
Odd numbers up to 20: 
1 3 5 7 9 11 13 15 17 19 
