Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example10.py ===
1 for displaying items
2 for searching an item
3 for quit

Type option 1 to 3 only:2
Type to search a name: LEE
Name:  Lee  found
1 for displaying items
2 for searching an item
3 for quit

Type option 1 to 3 only:3
