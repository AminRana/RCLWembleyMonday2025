Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example6.py ====
Type your IT mark: 70
Type your Science mark: 68
Your average mark:  69.0
Your grade: Merit
