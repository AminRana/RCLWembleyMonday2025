Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example20.py ===
Type your first number:12
Type your second number:6
1. Add
2. Sub
3. Quit
Type your option:2
Difference of the two numbers: 6
Type your first number:4
Type your second number:5
1. Add
2. Sub
3. Quit
Type your option:1
Total of the two numbers: 9
Type your first number:8
Type your second number:2
1. Add
2. Sub
3. Quit
Type your option:3
