Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example11.py ===
10 9 8 7 6 5 4 3 2 1 
20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 
100 99 98 97 96 95 94 93 92 91 
