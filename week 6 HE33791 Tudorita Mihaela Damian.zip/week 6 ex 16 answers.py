Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
==== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 6 - Examples\example16.py ===
Type your number: 5
120
The same can be done by using a for loop
120
