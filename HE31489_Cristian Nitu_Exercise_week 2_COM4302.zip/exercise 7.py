#7. Input & print names and ages
your_name = input("Enter your name: ")
your_age = int(input("Enter your age: "))
friend_name = input("Enter your friend's name: ")
friend_age = int(input("Enter your friend's age: "))

print("Output:")
print(f"Your name is {your_name} and you are {your_age} years old.")
print(f"Your friend's name is {friend_name} and they are {friend_age} years old.")
