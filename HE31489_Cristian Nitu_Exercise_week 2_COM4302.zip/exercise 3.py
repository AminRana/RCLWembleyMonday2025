#3.Calculate Total interest
capital = float(input("Enter capital amount: "))
interest_rate = float(input("Enter yearly interest rate (%): "))
years = int(input("Enter number of years: "))

total_interest = capital * interest_rate * years
print(f"Total Interest: {total_interest:.2f}")
