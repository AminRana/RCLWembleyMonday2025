#6. Calculate remainder (Modulus)
dividend = int(input("Enter dividend: "))
divisor = int(input("Enter divisor: "))

remainder = dividend % divisor
print(f"Remainder when {dividend} is divided by {divisor} is: {remainder}")
