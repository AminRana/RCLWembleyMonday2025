#5. Function to calculate power of a number
def calculate_power(base, exponent):
    return base ** exponent

base = int(input("Enter base number: "))
exponent = int(input("Enter exponent: "))

print(f"{base} to the power {exponent} is: {calculate_power(base, exponent)}")
