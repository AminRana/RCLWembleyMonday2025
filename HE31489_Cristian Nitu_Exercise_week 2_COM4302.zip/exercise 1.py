#1.Addition and Multiplication of two numbers
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

sum_result = num1 + num2
product_result = num1 * num2

print(f"Addition: {sum_result}")
print(f"Multiplication: {product_result}")
