#4.Calculate Age in Days
name = input("Enter your name: ")
age = int(input("Enter your age in years: "))

days = age * 365
print(f"{name}, you are approximately {days} days old.")
