#2. Calculate Area of a Cylinder
pi = 3.14159
radius = float(input("Enter radius of the cylinder: "))
height = float(input("Enter height of the cylinder: "))

volume = pi * radius**2 * height
print(f"Volume of Cylinder: {volume:.2f}")
