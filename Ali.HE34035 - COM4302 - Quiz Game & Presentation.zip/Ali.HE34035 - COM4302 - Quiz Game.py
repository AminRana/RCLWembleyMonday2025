
# Quiz Game: Menu-Based Multiple Choice Quiz
# Author: COM4302 Student
# Description: A simple terminal-based quiz game with topic selection and score tracking

def display_menu():
    print("Welcome to the Quiz Game!")
    print("Please choose a topic:")
    print("1. General Knowledge")
    print("2. Science")
    print("3. Exit")

def get_questions(topic):
    if topic == "1":
        return [
            {"question": "What is the capital of France?", "options": ["Paris", "London", "Berlin", "Rome"], "answer": "Paris"},
            {"question": "Which planet is known as the Red Planet?", "options": ["Earth", "Mars", "Jupiter", "Saturn"], "answer": "Mars"},
            {"question": "Who wrote 'Hamlet'?", "options": ["Shakespeare", "Dickens", "Hemingway", "Austen"], "answer": "Shakespeare"}
        ]
    elif topic == "2":
        return [
            {"question": "What is the chemical symbol for water?", "options": ["H2O", "O2", "CO2", "NaCl"], "answer": "H2O"},
            {"question": "What part of the cell contains DNA?", "options": ["Nucleus", "Ribosome", "Mitochondria", "Golgi"], "answer": "Nucleus"},
            {"question": "What force keeps us on the ground?", "options": ["Magnetism", "Gravity", "Friction", "Tension"], "answer": "Gravity"}
        ]
    else:
        return []

def run_quiz(questions):
    score = 0
    for i, q in enumerate(questions, 1):
        print(f"\nQuestion {i}: {q['question']}")
        for idx, option in enumerate(q['options'], 1):
            print(f"{idx}. {option}")
        try:
            user_input = int(input("Enter the option number: "))
            if q['options'][user_input - 1].lower() == q['answer'].lower():
                print("Correct!")
                score += 1
            else:
                print(f"Wrong! The correct answer was: {q['answer']}")
        except (ValueError, IndexError):
            print("Invalid input. Please enter a number between 1 and 4.")
    print(f"\nQuiz completed! Your score is {score}/{len(questions)}.")

def main():
    while True:
        display_menu()
        choice = input("Enter your choice: ")
        if choice == "3":
            print("Thank you for playing. Goodbye!")
            break
        questions = get_questions(choice)
        if questions:
            run_quiz(questions)
        else:
            print("Invalid topic selected. Please choose again.")

# Start the quiz game
if __name__ == "__main__":
    main()
