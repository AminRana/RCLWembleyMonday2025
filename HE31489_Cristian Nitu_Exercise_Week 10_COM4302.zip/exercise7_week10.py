#exercise 7-Book tracking program
books = [
    [101, "Introduction to Python", "Hardcopy", "Mizanur Rahman", 2023, 5.00],
    [102, "Cyberhacking techniques", "Softcopy", "Unknown", 2024, 2.99],
    [103, "Microprocessor", "Hardcopy", "Mizanur Rahman", 2002, 3.99],
    [104, "Computer Science", "Hardcopy", "CGP Books", 2023, 11.03],
    [105, "Python All-in-one", "Hardcopy", "John C. Shovic", 2024, 25.83]
]

def display_books():
    print("\n📚 Book Collection:")
    for book in books:
        book_id, title, type_, author, year, price = book
        print(f"{book_id} → '{title}' [{type_}], Author: {author}, Year: {year}, Price: £{price:.2f}")

display_books()
