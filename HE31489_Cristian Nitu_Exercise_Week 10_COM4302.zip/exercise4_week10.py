#Exercise 4-Student registry system
register = [
    ["Dili", "On time", "Yes"],
    ["Jack", "On time", "No"],
    ["Krist", "Late", "Yes"],
    ["Den", "On time", "Yes"]
]

def display_register():
    print("\n📋 Student Register:")
    for student in register:
        name, arrival, laptop = student
        print(f"{name} → Arrival: {arrival}, Laptop: {laptop}")

display_register()
