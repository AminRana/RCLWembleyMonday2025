#exercise 6-Home items listing program
home_items = [
    [1, "TV", "Equipment", "Old", 2, 200],
    [2, "Table", "Furniture", "New", 1, 350],
    [3, "Microwave", "Equipment", "New", 1, 100],
    [4, "Beds", "Furniture", "Old", 3, 100],
    [5, "Plates", "Household", "Old", 10, 1]
]

def display_home_items():
    print("\n🏡 Home Items:")
    for item in home_items:
        item_id, name, type_, status, qty, price = item
        print(f"{item_id}. {name} ({type_}) – {status}, Qty: {qty}, Estimated Price: £{price}")

display_home_items()
