#exercise 5-Student performance tracking
performance = [
    ["Mahid", 4, "Swimming", "Merit"],
    ["Belly", 3, "Social media", "Pass"],
    ["John", 6, "Web surfing", "Distinction"],
    ["Finn", 2, "Football", "Pass"]
]

def display_performance():
    print("\n📈 Student Performance:")
    for name, hours, hobby, result in performance:
        print(f"{name} → Study Hours: {hours}, Hobby: {hobby}, Expected Result: {result}")

display_performance()
