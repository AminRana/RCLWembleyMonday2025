#Exercise 1-Salary calculation program
staff_data = [
    ["Ram", 12.50, 30],
    ["Helen", 15.00, 28],
    ["Goald", 13.25, 40],
    ["Bens", 18.40, 25]
]

def calculate_salary(rate, hours):
    return rate * hours

def display_salaries():
    print("\n💼 Staff Salaries:")
    for name, rate, hours in staff_data:
        total = calculate_salary(rate, hours)
        print(f"{name} → Rate: £{rate}, Hours: {hours}, Total: £{total:.2f}")

display_salaries()
