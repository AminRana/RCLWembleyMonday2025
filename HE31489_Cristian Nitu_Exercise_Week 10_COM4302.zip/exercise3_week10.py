#Exercise 3-Sales tracking system
sales_data = [
    ["Ben", 2600, "Yes"],
    ["Bull", 3000, "No"],
    ["Jolly", 3500, "No"],
    ["Kal", 3200, "Yes"]
]

def display_sales():
    print("\n🛒 Sales Performance:")
    for name, total, target_met in sales_data:
        print(f"{name} → Sales: £{total}, Target Met: {target_met}")

display_sales()
