#Exercise 2-assignment tracking system
assignments = [
    ["John", "16/03/2025", "Yes", 3200],
    ["Bob", "", "No", 0],
    ["Dolly", "", "No", 0],
    ["Henry", "18/03/2025", "Yes", 2950],
    ["Joy", "19/03/2025", "Yes", 3100]
]

def display_assignments():
    print("\n📚 Assignment Submissions:")
    for student in assignments:
        name, date, status, words = student
        info = f"{name} → Submitted: {status}"
        if status == "Yes":
            info += f" on {date}, Words: {words}"
        else:
            info += ", Words: 0"
        print(info)

display_assignments()
