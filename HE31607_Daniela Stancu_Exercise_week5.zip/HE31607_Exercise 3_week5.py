#Exercise 3
#a. Look at Exercise 1a & 2a where you created a multidimensional list and dictionary respectively over a week’s weather
#information (e.g., day name (Sunday, Monday, Tuesday, etc) , temperature (e.g., 5, 12, 7, 8, etc) and outlook of the day(Fogy,
#Sunny, Cloudy, Cloudy, etc) and add a new record, print weather data, and delete a record and print it again. You will store some
#data into a CSV file and re-write the same program to ensure it works with data file well or use days.csv file provided.
import csv
#Load weather data from CSV
with open("days.csv", newline='') as file:
    reader = csv.reader(file)
    weather_week = list(reader)
#Add a new day
weather_week.append(["ExtraDay", "15", "Stormy"])
#Print update data
print("After Adding New Record:")
for row in weather_week:
    print(row)
#Delete a record (e.g., Tuesday)
weather_week = [day for day in weather_week if day[0] != "Tuesday"]
#Print after deletion
print("\nAfter Deleting Tuesday:")
for row in weather_week:
      print(row)
    
#b. Look at Exercise 1b & 2b where you created a multidimensional list and dictionary respectively over part time staff salary
#system to calculate total weekly gross salary for staff (multiply hourly rate and weekly hours), add a new record and total gross
#salary for all staff. You store some data into a CSV file and re-write your program to ensure it works well or use salary.csv file.
import csv
#Load salary data from CSV

with open("salary.csv", newline='') as file:
    reader = csv.reader(file)
    staff = list(reader)
    
#Add new record
staff.append(["Daisy", "11", "18"])
#Calculate salaries
total_salary = 0
print("Weekly Gross Salaries:")
for s in staff:
    name, rate, hours = s
    gross = float(rate) * float(hours)
    total_salary += gross
    print(f"{name}: £{gross}")
print(f"\nTotal Gross Salary: £{total_salary}")
              
#c. Look at Exercise 1c & 2c where you created a multidimensional list and dictionary respectively for a simple assignment tracking
#system where you should have at least student name, date, yes/no (for submission status) and number of words columns. The
#system will display all students, list of students who submitted the assignments and list of students who didn’t submit the
#assignments. Re-write the same program using students.csv file.
import csv
#Load assigments data
with open("students.csv", newline='') as file:
    reader = csv.reader(file)
    assignments = list(reader)
#Print all
print("All Assignments:")
for student in assignments:
    print(student)
#Submitted
print("\nSubmitted Assignments:")
for s in assignments:
    if s[2].lower() == "yes":
        print(s)
#Not submitted
print("\nMissing Assignments:")
for s in assignments:
    if s[2].lower() == "no":
        print(s)
    

#d. Look at Exercise 1d & 2d where you created a multidimensional list and dictionary respectively a simple sales tracking system
#with at least staff name, total sales, yes/no (target met) columns. The system will print all staff’s sales information, total of sales
#of all staff, staff list who met the sales target and their total sales, and staff list who did not meet the sales target and their total
#sales. Re-write the program for the same functionality using targetsales.csv file.
import csv
#Load sales data
with open("targetsales.csv", newline='') as file:
    reader = csv.reader(file)
    sales = list(reader)
#Print all sales
print("All Sales Records:")
for record in sales:
    print(record)
#Total sales
total = sum([float(s[1]) for s in sales])
print(f"\nTotal Sales: £{total}")
#Met target
print("\nTarget Met:")
met = [s for s in sales if s[2].lower() == "yes"]
for m in met:
    print(m)
print(f"\nTotal Met Sales: £{sum([float(s[1]) for s in met])}")
#Not met target
print("\nTaget Not Met:")
not_met = [s for s in sales if s[2].lower() == "no"]
for n in not_met:
    print(n)
print(f"Total Not Met Sales: £{sum([float(s[1]) for s in not_met])}")
