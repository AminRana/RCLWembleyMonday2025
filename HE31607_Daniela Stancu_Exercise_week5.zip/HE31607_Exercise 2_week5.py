#a. Look at Exercise 1a & 2a where you created a multidimensional list and dictionary respectively over a week’s weather
#information (e.g., day name (Sunday, Monday, Tuesday, etc) , temperature (e.g., 5, 12, 7, 8, etc) and outlook of the day(Fogy,
#Sunny, Cloudy, Cloudy, etc) and add a new record, print weather data, and delete a record and print it again. You will store some
#data into a CSV file and re-write the same program to ensure it works with data file well or use days.csv file provided.
import csv
filename = "days.csv"
weather_list ={"Sunday": {"temperature": 18, "outlook": "Sunny"},
               "Monday":{"temperature":8, "outlook": "Fogy"},
               "Tuesday":{"temperature":5, "outlook": "Cloudy"}}
#Add new day
weather_list["Thursday"] = {"temperature":30, "outlook": "Hot"}
print("After adding new record:")
for day, data in weather_list.items():
     print(f"{day}: {data}")
#Delete a day
del weather_list["Tuesday"]
print("\nAfter deleting Tuesday:")
for day, data in weather_list.items():
     print(f"{day}:{data}")
               
#b. Look at Exercise 1b & 2b where you created a multidimensional list and dictionary respectively over part time staff salary
#system to calculate total weekly gross salary for staff (multiply hourly rate and weekly hours), add a new record and total gross
#salary for all staff. You store some data into a CSV file and re-write your program to ensure it works well or use salary.csv file.
staff_data = {"Sarah": {"rate":15, "hours": 20},
             "Rita": {"rate":12, "hours": 25},
             "Sam": {"rate":16, "hours": 18}}
#Add new staff record
staff_data["Tom"] = {"rate":20, "hours": 12}
#Calculate and display gross salaries
total_salary = 0
print("Weekly Gross Salaries:")
for name, info in staff_data.items():
     gross = info["rate"] * info["hours"]
     total_salary += gross
     print(f"{name}: £{gross}") 
print(f"\nTotal Gross salary: £{total_salary}")
#c. Look at Exercise 1c & 2c where you created a multidimensional list and dictionary respectively for a simple assignment tracking
#system where you should have at least student name, date, yes/no (for submission status) and number of words columns. The
#system will display all students, list of students who submitted the assignments and list of students who didn’t submit the
#assignments. Re-write the same program using students.csv file.
assignments = {"Maria": {"date": "09-07-2025","submitted": "Yes", "words": 1200},
               "Amanda": {"date": "10-07-2025","submitted": "No", "words": 0},
              "Max": {"date": "09-07-2025","submitted": "Yes", "words": 1100}}
#Add new student
assignments["Tania"] = {"date": "11-07-2025","submitted": "No", "words": 0}
#Display all records
print("All Assignment records:")
for name, data in assignments.items():
     print(f"{name}: {data}")
#Submitted list
print("\nSubmitted assignments:")
for name, data in assignments.items():
     if data["submitted"].lower() == "yes":
          print(f"{name}: {data}")
#Not submitted list
print("\nMissing Assignments:")
for name, data in assignments.items():
     if data["submitted"].lower() == "no":
          print(f"{name}: {data}")
#d. Look at Exercise 1d & 2d where you created a multidimensional list and dictionary respectively a simple sales tracking system
#with at least staff name, total sales, yes/no (target met) columns. The system will print all staff’s sales information, total of sales
#of all staff, staff list who met the sales target and their total sales, and staff list who did not meet the sales target and their total
#sales. Re-write the program for the same functionality using targetsales.csv file
sales = {"Ella": {"total": 1250, "target_met": "Yes"},
         "Carmen": {"total": 800, "target_met": "No"},
         "Andreea": {"total": 1600, "target_met": "Yes"}}
#All sales data print("All Staff Sales Info:")
for name, data in sales.items():
    print(f"{name}: {data}")
#Total sales
total_all = sum([info["total"] for info in sales.values()])
print(f"\nTotal Sales: £{total_all}")
#Staff who met target
print("\nStaff Met Target:")
met = {name: data["total"] for name, data in sales.items() if data["target_met"] == "Yes"}
for name, total in met.items():
    print(f"{name}: £{total}")
print(f"Total (Target Met): £{sum(met.values())}")
#Staff who didn't met target
print("\nStaff Did Not Meet Target:")
not_met = {name: data["total"] for name,data in sales.items() if data["target_met"] == "No"}
for nmae, total in not_met.items():
    print(f"{name}: £{total}")
print(f"Total (Target Not Met): £{sum(not_met.values())}")
      
               

     
