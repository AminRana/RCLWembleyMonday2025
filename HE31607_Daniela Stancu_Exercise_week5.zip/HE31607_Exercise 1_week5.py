#a. Write a program to create a 3D list over a week’s weather information (e.g., day name (Sunday, Monday, Tuesday, etc)
##, temperature (e.g., 5, 12, 7, 8, etc) and outlook of the day(Fogy, Sunny, Cloudy, Cloudy, etc) and use enumerate()
#function with it, and add a new record with the existing list, print it, and delete a record and print it again
print("3D List:")
Weatherlist=[["Sunday",18,"Sunny"],["Monday",8,"Fogy"],["Tuesday",5,"Cloudy"],["Wednesday",7,"Windy"],["Thursday",10,"Sunny"],["Friday",9,"Rainy"],["Saturday",4,"Cloudy"]]
#Print original data
print("Weatherlist")
for index, day in enumerate(Weatherlist):
    print(f"{index}: {day}")
#Add new record
newday=["Thursday",30,"Hot"]
Weatherlist.append(newday)
print("\nAfter adding new record:")
for index, day in enumerate(Weatherlist):
    print(f"{index}:{day}")
#Delete a record (e.g., Tuesday - index 2)
del Weatherlist[2]
print("\nAfter deleting a record:")
for index, day in enumerate(Weatherlist):
    print(f"{index},{day}")
#b. Write a program for part time staff salary system to calculate total weekly gross salary for staff (multiply hourly rate
#and weekly hours), add a new record and total gross salary for all staff. The multidimensional list should have minimum
#staff name, hourly rate and weekly hours columns
staffsalary=[["Sarah", 15, 20],["Rita", 12, 25],["Sam", 18, 16]]
#Add new record
staffsalary.append(["Tom", 20, 12])
#Calculate and print salaries
print("\nWeely Gross Salaries:")
for staff in staffsalary:
    name, rate, hours =staff
    salary =rate * hours
    print(f"{name}, £{salary}")

#c. Write a program to create a simple assignment tracking system where you should have at least student name, date,
#yes/no (for submission status) and number of words columns. The system will display all students, allow to enter a new
#record, list of students who submitted the assignments and list of students who didn’t submit the assignments.
assignments=[["Maria", "09-07-2025","Yes",1200],["Amanda","10-07-2025","No",0],["Max","09-07-2025",1100]]
#Add new record
assignments.append(["Tania","11-07-2025","No",0])
#Display all students
print("\nAll Assignments:")
for record in assignments:
    print(record)
    
#List who submitted
    print("\nSubmitted Assignments:")
    for record in assignments:
        if record[2]=="Yes":
            print(record[0])
        
#List who didn't submitted
    print("\nNot Submitted Assignments:")
    for record in assignments:
        if record[2]=="No":
            print(record[0])

#d. Write a program to create a simple sales tracking system with at least staff name, total sales, yes/no (target met or
#not) columns. The system will print all staff’s sales information, total of sales of all staff, staff list who met the sales
#target and their total sales, and staff list who did not meet the sales target and their total s
salesdata=[["Ella",1250, "Yes"],["Carmen",800, "No"],["Andreea",1600, "Yes"]]
#Add new records
salesdata.append(["Robert",800, "No"])

#Display all sales
print("\nAll Sales Data:")
for record in salesdata:
    print(record)

#Total sales of all staff
totalsales=sum([record[1] for record in salesdata])
print(f"\nTotal Sales if All Staff: £{totalsales}")

#Staff who met the target
print("\nStaff Who Met Sales Target:")
for record in salesdata:
    if record[2] == "Yes":
        print(f"{record[0]} - £{record[1]}")

#Staff who didn't meet the target
print("\nStaff Who Did NOT Meet Sales Target:")
for record in salesdata:
    if record[2] == "No":
        print(f"{record[0]} - £{record[1]}")
