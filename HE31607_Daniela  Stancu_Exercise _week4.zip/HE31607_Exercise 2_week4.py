#a. Write a program to print numbers from 1 to 6 with their square, Cube and multiplication of the number 4 times. For
#example, the output would be:
#1= 1, 1, 1, 1 4=4, 16, 64, 256
#2=2, 4, 8, 16 5=5, 25, 125, 625
#3=3, 9, 27, 81 6=6, 36, 216, 1,296
for i in range(1, 7):
    square = i ** 2
    cube = i ** 3
    power4 = i ** 4
    print(f"{i} = {i}, {square}, {cube}, {power4}")
    
    
#b. Write a program to print from 1 to 50 with 5 lines/rows. For example, First line will print 1 to 10, 2nd line/row will print 11 to
#20, 3rd line/row will print 31 to 40, and so on
for i in range(1, 51):
    print(f"{i:2}", end=' ')
    if i % 10 == 0:
        print()  # New line after every 10 numbers

        
#c. Write a program to create sequence like print 0, 1, 2 and 3 in the first row; 10, 11, 12 and 13 in the 2nd row, 20, 21, 22 and
#23 in the 3rd row and so on up to 100
for row in range(0, 101, 10):
    for col in range(4):  # print 4 numbers per row
        print(row + col, end=' ')
    print()  # new row

    
#d. Write a program to create a timetable up 10. For example, the output of the program will be like below:
#1=1×1=1 1×2=2 1×3=3 1×4=4. 1×10=10 ‐----------------------------------------------------------
#2=2×1=2 2×2=4 2×3=6 2×4=8. 2×10=20 10=10×1=10 10×2=20 10×3=30 10×10=1000
#3=3×1=3 3×2=6 3×3=9 3×4=12. 3×10=30
for i in range(1, 11):
    print(f"\n{i} = ", end='')
    for j in range(1, 11):
        print(f"{i}×{j}={i*j}", end='  ')
