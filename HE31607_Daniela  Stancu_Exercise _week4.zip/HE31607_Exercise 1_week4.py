#a. Write a program to iterate all characters of a string (one by one) using a for loop and check it is a vowel or
#not.
text = input("Enter a string: ")
for char in text:
    if char.lower() in 'aeiou':
        print(f"{char} is a vowel. ")
    else:
        print(f"{char} is not a vowel. ")
        
#b. Write a program to add all even numbers up to 20. For example, the program will add 2, 4, 6, up to 20.
total = 0
for i in range(2, 21, 2):
    total += i
print(f"Sum of even numbers from 2 to 20 is: {total}")

#c. Previously under Week 3 Exercise 3c, you have created a menu program, and it was not effectively. Write a
#menu program (like 1 for Add, 2 for Search, 3 for Update, 4 for Delete and 5 for Quit) where the program will
#continue until user types 5 to quit.
while True:
    print("\nMenu:")
    print("1. Add")
    print("2. Search")
    print("3. Update")
    print("4. Delete")
    print("5. Quit")
    choice = int(input("Enter your choice (1-5): "))
    
    if choice == 1:
        print("Add selected.")
    elif choice == 2:
        print("Search selected.")
    elif choice == 3:
        print("Update selected.")
    elif choice == 4:
        print("Delete selected.")
    elif choice == 5:
        print("Quitting the program. Goodbye!")
        break
    else:
        print("Invalid choice. Please enter a number from 1 to 5.")
    
#d. Write a program to check and print whether it is a prime number or not. Hints: prime number can be divisible
#by the number itself and 1 only.
num = int(input("Enter a number to check if it is prime: "))

if num <= 1:
    print(f"{num} is not a prime number.")
else:
    is_prime = True
    for i in range(2, int(num**0.5) + 1):  # Efficient check up to sqrt(num)
        if num % i == 0:
            is_prime = False
            break

    if is_prime:
        print(f"{num} is a prime number.")
    else:
        print(f"{num} is not a prime number.")
#e. Write a program to calculate a series of prime numbers up to a certain number. For example, 2, 3, 5, 7, 11,
#13 17 and 19 are prime numbers up to number 20.
limit = int(input("Enter a number to print all primes up to: "))

print("Prime numbers up to", limit, "are:")
for num in range(2, limit + 1):
    is_prime = True
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
    if is_prime:
        print(num, end=" ")        
#f. Write a program to create a timetable for a given number. For example, if 7 is typed as an input, the program
#will display 7×1=7, 7x2=14, 7x3=21, up to 7x10=70.
num = int(input("Enter a number to display its multiplication table: "))

print(f"\nMultiplication Table for {num}:")
for i in range(1, 11):
    print(f"{num} x {i} = {num * i}")
