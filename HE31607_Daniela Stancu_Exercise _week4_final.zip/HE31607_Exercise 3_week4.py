#3. Use the below list for question a to i
words = ['jam', 'argue', 'elf', 'brown', 'dice','dingo']
#words = ['jam', 'argue', 'elf', 'brown', 'dice', 'dingo']
#a) Add the word ‘poster’ to the end of the list
words.append('poster')
#b) Add the word ‘bin’ between elif and brown
words.insert(words.index('brown'), 'bin')
#c) Reverse the order of the list
words.reverse()
#d) Remove the word ‘dice’
if 'dice' in words:
    words.remove('dice')
#e) Add the list[‘table’, ‘brave’, ‘cat’] to the list of word
words += ['table', 'brave', 'cat']
#f) Create a new list called newWords to hold 2nd, 3rd and 4th items of words list
newwords = words[1:4]
#g) Print out words list in UPPER CASE
print("UPPER CASE:", [word.upper() for word in words])
#h) Print out words list in Title CASE
print("Title CASE:", [word.title() for word in words])
#i) Print out last three items from the words list
print("Last 3 items:", words[-3:])


#4. Use the below list for question a to i
#nums = [3, 7, 19, 2, 8, 3, 9, 1, 6]
#a) Place the number 4 at the end of the list.
#b) Place 23 between the 2 and the 8.
#c) Print the 5th to 7th numbers in the list.
#d) Add the list [3, 6, 9, 12] to the list nums.
#e) Reverse the list nums.
#f) Delete the 4th number.
#g) Sort the list in descending order
#h) Print out all odd numbers
#i) Add all numbers of the list

nums = [3, 7, 19, 2, 8, 3, 9, 1, 6]

# a) Place the number 4 at the end of the list
nums.append(4)

# b) Place 23 between the 2 and the 8
index = nums.index(2) + 1
nums.insert(index, 23)

# c) Print the 5th to 7th numbers in the list (index 4 to 6)
print("5th to 7th numbers:", nums[4:7])

# d) Add the list [3, 6, 9, 12] to nums
nums.extend([3, 6, 9, 12])

# e) Reverse the list
nums.reverse()

# f) Delete the 4th number (index 3)
del nums[3]

# g) Sort the list in descending order
nums.sort(reverse=True)

# h) Print out all odd numbers
odd_numbers = [n for n in nums if n % 2 != 0]
print("Odd numbers:", odd_numbers)

# i) Add all numbers of the list
total = sum(nums)
print("Sum of all numbers:", total)

# Final list output
print("Final list:", nums)

#5. Write a program to count number of items (e.g., colours list may have items – red, green, red, blue, yellow,
#pink, blue, green, blue, white) from a list of several strings based on user’s input
colours = ["red", "green", "red", "blue", "yellow",
           "pink", "blue", "green", "blue", "white"]

# Ask user to enter a color
user_input = input("Enter a color to count: ").lower()

# Convert all list items to lowercase for case-insensitive comparison
count = sum(1 for color in colours if color.lower() == user_input)

# Display result
print(f"The color '{user_input}' appears {count} time(s) in the list.")
#6. Write a menu program (e.g., 1 for Display, 2 for Add, 3 for Delete and 4 for Quit) with a while loop and a list
#with some strings
items = ["apple", "banana", "cherry"]

while True:
    print("\nMenu:")
    print("1. Display items")
    print("2. Add an item")
    print("3. Delete an item")
    print("4. Quit")
    
    choice = input("Enter your choice (1–4): ")
    
    if choice == "1":
        print("Items in the list:", items)
    elif choice == "2":
        new_item = input("Enter item to add: ")
        items.append(new_item)
        print(f"{new_item} added.")
    elif choice == "3":
        item_to_delete = input("Enter item to delete: ")
        if item_to_delete in items:
            items.remove(item_to_delete)
            print(f"{item_to_delete} removed.")
        else:
            print(f"{item_to_delete} not found.")
    elif choice == "4":
        print("Quitting program.")
        break
    else:
        print("Invalid choice. Please select 1-4.")
