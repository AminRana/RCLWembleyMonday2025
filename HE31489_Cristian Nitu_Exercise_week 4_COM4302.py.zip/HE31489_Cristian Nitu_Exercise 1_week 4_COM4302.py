#Exercise 1
#a. Iterate characters and check for vowels
text = "Hello World"
vowels = "aeiouAEIOU"
for char in text:
    if char in vowels:
        print(f"{char} is a vowel")
    else:
        print(f"{char} is not a vowel")
        
#b. Add even number up to 20
number = 1
for row in range(5):
    line = []
    for col in range(10):
        line.append(f"{number:02}")  # Pads single digits with 0
        number += 1
    print(" ".join(line))


#c. Menu program (loop until user quits)
for row_start in range(0, 101, 10):
    line = []
    for offset in range(4):
        line.append(str(row_start + offset))
    print(" ".join(line))


#d. Check if a number is prime
for i in range(1, 11):
    for j in range(1, 11):
        print(f"{i}×{j}={i*j:<3}", end="\t")
    print()
    


#e. Print prime numbers up to a given number
def print_primes_up_to(limit):
    print(f"Prime numbers up to {limit} are:")
    for num in range(2, limit + 1):
        is_prime = True
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                is_prime = False
                break
        if is_prime:
            print(num, end=" ")
    print()

# Example usage:
def multiplication_table(n):
    print(f"\nMultiplication table for {n}:")
    for i in range(1, 11):
        print(f"{n} × {i} = {n * i}")

# Example usage:
multiplication_table(7)

