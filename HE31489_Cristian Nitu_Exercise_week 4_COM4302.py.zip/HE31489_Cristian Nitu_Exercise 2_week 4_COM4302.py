#Exercise 2
#a. Number with square, cube, and multiplied 4 times
for i in range(1, 7):
    result = []
    value = i
    for _ in range(4):
        result.append(value)
        value *= i
    print(f"{i} = {', '.join(map(str, result))}")
#b. Print numbers from 1 to 50 in 5 rows
number = 1
for row in range(5):
    line = []
    for col in range(10):
        line.append(str(number))
        number += 1
    print(" ".join(line))
    
#c.Sequence like 0-3, 10-13, ...100-103
for row in range(0, 101, 10):
    line = []
    for col in range(4):
        line.append(str(row + col))
    print(" ".join(line))

#d. Multiplication table up to 10
for i in range(1, 11):
    line = []
    for j in range(1, 11):
        line.append(f"{i}×{j}={i*j}")
    print(" ".join(line))

