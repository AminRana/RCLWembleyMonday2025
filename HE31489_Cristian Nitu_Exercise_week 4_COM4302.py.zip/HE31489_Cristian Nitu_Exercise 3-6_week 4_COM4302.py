#Exercise 3-6
#3. Working with wods list
words = ['jam', 'argue', 'elf', 'brown', 'dice', 'dingo']

# a) Add 'poster' to the end
words.append('poster')

# b) Add 'bin' between 'elf' and 'brown'
words.insert(words.index('brown'), 'bin')

# c) Reverse the list
words.reverse()

# d) Remove 'dice'
words.remove('dice')

# e) Add ['table', 'brave', 'cat']
words += ['table', 'brave', 'cat']

# f) Create newWords with 2nd, 3rd, 4th items
newWords = words[1:4]

# g) Print list in UPPER CASE
print([word.upper() for word in words])

# h) Print list in Title CASE
print([word.title() for word in words])

# i) Print last three items
print(words[-3:])

#Exercise 4
#4. Working with numbers list

nums = [3, 7, 19, 2, 8, 3, 9, 1, 6]

# a) Add 4 to the end
nums.append(4)

# b) Insert 23 between 2 and 8
nums.insert(nums.index(8), 23)

# c) Print 5th to 7th numbers
print(nums[4:7])

# d) Add [3, 6, 9, 12]
nums += [3, 6, 9, 12]

# e) Reverse the list
nums.reverse()

# f) Delete the 4th number
del nums[3]

# g) Sort descending
nums.sort(reverse=True)

# h) Print all odd numbers
print([n for n in nums if n % 2 != 0])

# i) Sum all numbers
print(sum(nums))

#Exercise 5
#5. Count items from list based on user's input
colours = ['red', 'green', 'red', 'blue', 'yellow', 'pink', 'blue', 'green', 'blue', 'white']
target = input("Enter a colour to count: ").lower()
count = colours.count(target)
print(f"{target} appears {count} times.")

#Exercise 6
#6. Menu-driven program using a string list
items = ['apple', 'banana', 'carrot']
while True:
    print("\nMENU")
    print("1. Display\n2. Add\n3. Delete\n4. Quit")
    choice = input("Enter choice: ")

    if choice == '1':
        print("Items:", items)
    elif choice == '2':
        new_item = input("Enter item to add: ")
        items.append(new_item)
    elif choice == '3':
        del_item = input("Enter item to delete: ")
        if del_item in items:
            items.remove(del_item)
        else:
            print("Item not found.")
    elif choice == '4':
        print("Goodbye!")
        break
    else:
        print("Invalid choice, try again.")

