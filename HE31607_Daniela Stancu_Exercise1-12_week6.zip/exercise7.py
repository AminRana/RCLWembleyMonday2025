#7. Create a dictionary with the following students’ data (add more if you wish) and
#then create a few functions for different purposes such as total of each student’s
#mark, calculate grade and search a student.
#students={"Mizan": {"IT": 86, "Science":69},
#"Ram":{"IT": 75, "Science":46},
#"John":{"IT": 35, "Science":50},
#"Ann":{"IT": 55, "Science":76},
#"Chris":{"IT": 45, "Science":65}}
students = {
    "Mizan": {"IT": 86, "Science": 69},
    "Ram": {"IT": 75, "Science": 46},
    "John": {"IT": 35, "Science": 50},
    "Ann": {"IT": 55, "Science": 76},
    "Chris": {"IT": 45, "Science": 65}
}

def calculate_totals():
    print("\nTotal Marks for Each Student:")
    for name, subjects in students.items():
        total = sum(subjects.values())
        print(f"{name}: {total}")

def calculate_grades():
    print("\nGrades for Each Student:")
    for name, subjects in students.items():
        avg = sum(subjects.values()) / len(subjects)
        if avg >= 80:
            grade = 'A'
        elif avg >= 60:
            grade = 'B'
        elif avg >= 40:
            grade = 'C'
        else:
            grade = 'F'
        print(f"{name}: Grade {grade} (Avg: {avg:.1f})")

def search_student():
    search_name = input("Enter student name to search: ").strip().capitalize()
    if search_name in students:
        print(f"\nFound {search_name}'s marks:")
        for subject, mark in students[search_name].items():
            print(f"{subject}: {mark}")
    else:
        print(f"\nStudent '{search_name}' not found.")

# Test the functions
calculate_totals()
calculate_grades()
search_student()
