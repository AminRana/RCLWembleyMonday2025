#12. Modify Week 4 Exercise 8 program and make it better using function

# ------ Part A: Vowel checker ------
def check_vowels():
    text = input("Enter a string: ")
    for char in text:
        if char.lower() in 'aeiou':
            print(f"{char} is a vowel.")
        else:
            print(f"{char} is not a vowel.")

# ------ Part B: Sum even numbers up to 20 ------
def sum_even_1_to_20():
    total = sum(range(2, 21, 2))
    print(f"Sum of even numbers from 2 to 20 is: {total}")

# ------ Part C: Menu (Add/Search/Update/Delete) ------
def list_menu():
    data = []
    while True:
        print("\n[ List Menu ]")
        print("1. Add")
        print("2. Search")
        print("3. Update")
        print("4. Delete")
        print("5. Quit")
        choice = input("Enter choice (1–5): ")

        if choice == '1':
            item = input("Enter item to add: ")
            data.append(item)
            print("Added.")
        elif choice == '2':
            search = input("Enter item to search: ")
            found = data.count(search)
            print(f"'{search}' appears {found} time(s).")
        elif choice == '3':
            old = input("Enter item to update: ")
            if old in data:
                new = input("Enter new value: ")
                data[data.index(old)] = new
                print("Updated.")
            else:
                print("Item not found.")
        elif choice == '4':
            rem = input("Enter item to delete: ")
            if rem in data:
                data.remove(rem)
                print("Deleted.")
            else:
                print("Not found.")
        elif choice == '5':
            break
        else:
            print("Invalid choice.")

# ------ Part D: Prime check ------
def check_prime():
    num = int(input("Enter number to check for prime: "))
    if num <= 1:
        print(f"{num} is not prime.")
        return
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            print(f"{num} is not prime.")
            return
    print(f"{num} is prime.")

# ------ Exercise 4: List Manipulation (a–i) ------
def list_operations():
    nums = [3, 7, 19, 2, 8, 3, 9, 1, 6]
    print(f"Original: {nums}")

    nums.append(4)
    nums.insert(nums.index(2)+1, 23)
    print("5th–7th elements:", nums[4:7])
    nums.extend([3, 6, 9, 12])
    nums.reverse()
    del nums[3]
    nums.sort(reverse=True)
    odds = [n for n in nums if n % 2]
    total = sum(nums)

    print("After mods:", nums)
    print("Odds:", odds)
    print("Sum:", total)

# ------ Exercise 5: Count occurrences ------
def count_occurrences():
    colours = ["red", "green", "red", "blue", "yellow",
               "pink", "blue", "green", "blue", "white"]
    target = input("Color to count: ").lower()
    cnt = sum(c.lower() == target for c in colours)
    print(f"'{target}' found {cnt} time(s).")

# ------ Exercise 6: Menu with items list ------
def items_menu():
    items = ["apple", "banana", "cherry"]
    while True:
        print("\n[ Items Menu ]")
        print("1. Display")
        print("2. Add")
        print("3. Delete")
        print("4. Quit")
        choice = input("Choice (1–4): ")

        if choice == '1':
            print("Items:", items)
        elif choice == '2':
            new = input("Item to add: ")
            items.append(new)
            print("Added.")
        elif choice == '3':
            rem = input("Item to delete: ")
            if rem in items:
                items.remove(rem)
                print("Deleted.")
            else:
                print("Not found.")
        elif choice == '4':
            break
        else:
            print("Invalid.")

# ------ Parts A–D extras (patterns and tables) ------
def parts_ad_additional():
    # a extended: powers
    print("\n1 to 6 with powers:")
    for i in range(1,7):
        print(i, i**2, i**3, i**4)

    # b: 1–50 in rows
    print("\n1 to 50, rows of 10:")
    for i in range(1,51):
        print(f"{i:2}", end=' ')
        if i % 10 == 0:
            print()

    # c: sequence 0-3,10-13,..100-103
    print("\nSequence rows of 4 numbers:")
    for row in range(0,101,10):
        for col in range(4):
            print(row+col, end=' ')
        print()

    # d: multiplication tables
    print("\nMultiplication tables 1–10:")
    for i in range(1,11):
        print(f"\n{i} times table:")
        for j in range(1,11):
            print(f"{i}×{j}={i*j}")

# ------ Master Menu ------
def main():
    options = {
        '1': ("Check vowels", check_vowels),
        '2': ("Sum even 2–20", sum_even_1_to_20),
        '3': ("Simple list menu", list_menu),
        '4': ("Prime check", check_prime),
        '5': ("List operations (4)", list_operations),
        '6': ("Count occurrences (5)", count_occurrences),
        '7': ("Items menu (6)", items_menu),
        '8': ("Parts A–D extras", parts_ad_additional),
        '9': ("Quit", None)
    }

    while True:
        print("\n=== Exercise 12 Menu ===")
        for k, (desc, _) in options.items():
            print(f"{k}. {desc}")
        choice = input("Select an option: ")

        if choice == '9':
            print("Goodbye!")
            break
        action = options.get(choice)
        if action:
            action[1]()  # call the function
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
