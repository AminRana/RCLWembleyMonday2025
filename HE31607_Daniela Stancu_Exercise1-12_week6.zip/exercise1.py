#Exercise1.py
#1. Review Example1.py and expand the program adding another two functions – mul
#for multiplication and div for division of two numbers. Make sure it works and save it
#as exercise1.py into your working folder.
def add(x, y):
    return x+y
def sub(x, y):
    return x-y
def mul(x, y):
    return x*y
def div(x, y):
    if y == 0:
        return "Error! Division by zero."
    return x / y
#Test the functions
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

print(f"Adding: {add(num1, num2)}")
print(f"Subtrcting: {sub(num1, num2)}")
print(f"Multiplaying: {mul(num1, num2)}")
print(f"Dividing: {div(num1, num2)}")
