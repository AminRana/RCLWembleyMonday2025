#10. Similarly, modify your program of Exercise 7 to make it a menu program like
#Exercise 9. For example, type 1 for displaying students’ full data, 2 for displaying
#grades, 3 for searching a student and 4 for quit the program.



students = {
    "Mizan": {"IT": 86, "Science": 69},
    "Ram": {"IT": 75, "Science": 46},
    "John": {"IT": 35, "Science": 50},
    "Ann": {"IT": 55, "Science": 76},
    "Chris": {"IT": 45, "Science": 65}
}

def display_all_students():
    print("\nFull Student Data:")
    for name, subjects in students.items():
        print(f"{name}: {subjects}")

def display_grades():
    print("\nGrades:")
    for name, subjects in students.items():
        avg = sum(subjects.values()) / len(subjects)
        if avg >= 80:
            grade = 'A'
        elif avg >= 60:
            grade = 'B'
        elif avg >= 40:
            grade = 'C'
        else:
            grade = 'F'
        print(f"{name}: Grade {grade} (Avg: {avg:.1f})")

def search_student():
    name = input("Enter student name to search: ").strip().capitalize()
    if name in students:
        print(f"\n{name}'s Marks:")
        for subject, mark in students[name].items():
            print(f"{subject}: {mark}")
    else:
        print(f"{name} not found.")

def menu():
    while True:
        print("\nStudent Menu:")
        print("1. Display all student data")
        print("2. Display grades")
        print("3. Search a student")
        print("4. Quit")

        choice = input("Enter your choice (1-4): ").strip()

        if choice == "1":
            display_all_students()
        elif choice == "2":
            display_grades()
        elif choice == "3":
            search_student()
        elif choice == "4":
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1-4.")

# Run the menu
menu()










