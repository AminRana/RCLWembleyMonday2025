#6. Create a list of 10 fruits and create three functions – to print out the full list, count
#number of characters of each element in the list and add a new element in the list.
fruits = ["apple", "banana", "orange", "kiwi", "mango", "grape", "papaya", "pear", "peach", "plum"]

def print_fruits():
    print("\nFruit List:")
    for fruit in fruits:
        print(fruit)

def count_characters():
    print("\nNumber of characters in each fruit:")
    for fruit in fruits:
        print(f"{fruit}: {len(fruit)} characters")

def add_fruit():
    new_fruit = input("Enter a new fruit to add: ").strip().lower()
    if new_fruit not in fruits:
        fruits.append(new_fruit)
        print(f"{new_fruit} added to the list.")
    else:
        print(f"{new_fruit} is already in the list.")

# Run all functions
print_fruits()
count_characters()
add_fruit()
print_fruits()  # Show updated list
