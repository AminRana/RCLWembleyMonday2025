#4. Create a program to sum all digits of a number using a function. For example, if
#you add all digits of 432 you will get 4+3+2=9.
def sum_digits(num):
    total = 0
    for digit in str(num):
        if digit.isdigit():
            total += int(digit)
    return total
#Get user input
number = input("Enter a number:")
#Call the function and print result
result = sum_digits(number)
print(f"The sum of digits in {number} is: {result}")
