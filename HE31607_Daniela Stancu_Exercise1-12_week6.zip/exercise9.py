#9. Modify your program of exercise 1 again to make it a menu program. Make sure
#before completing this exercise, you are reviewing again example20.py and
#example20a.py where a menu program has been demonstrated. For example, your
#menu program will be like below:
#1. Adding
#2. Subtracting
#3. Multiplying
#4. Dividing
#5. Quit
def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def mul(x, y):
    return x * y

def div(x, y):
    if y == 0:
        return "Error! Division by zero."
    return x / y

def get_numbers():
    try:
        x = float(input("Enter first number: "))
        y = float(input("Enter second number: "))
        return x, y
    except ValueError:
        print("Invalid input. Please enter numbers.")
        return get_numbers()

def menu():
    while True:
        print("\nMenu:")
        print("1. Adding")
        print("2. Subtracting")
        print("3. Multiplying")
        print("4. Dividing")
        print("5. Quit")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            x, y = get_numbers()
            print(f"Result: {add(x, y)}")
        elif choice == "2":
            x, y = get_numbers()
            print(f"Result: {sub(x, y)}")
        elif choice == "3":
            x, y = get_numbers()
            print(f"Result: {mul(x, y)}")
        elif choice == "4":
            x, y = get_numbers()
            print(f"Result: {div(x, y)}")
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid option. Please choose 1-5.")

# Run the menu
menu()
