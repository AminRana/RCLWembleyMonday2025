#5. Create a program to calculate/print total, average and maximum of some numbers
#(4 or more numbers storing in a list) using functions.
def get_total(numbers):
    return sum(numbers)

def get_average(numbers):
    return sum(numbers) / len(numbers)

def get_maximum(numbers):
    return max(numbers)

# List of numbers
numbers = [10, 25, 30, 18, 42]

# Output results
print("Numbers:", numbers)
print("Total:", get_total(numbers))
print("Average:", get_average(numbers))
print("Maximum:", get_maximum(numbers))
