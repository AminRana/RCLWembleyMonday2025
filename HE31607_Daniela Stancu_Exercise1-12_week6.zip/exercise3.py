#3. Create a program with two functions to draw a triangle and rectangle shape with
#some stars(*). Yon can ask a user to type number of stars for the base of the triangle
#and rectangle shape.
#* **********
#** * *
#**** * *
#***** * *
#****** **********
#Triangle with a base of 6 stars(*) Rectangle with a base of 10 stars(*)
def draw_triangle(base):
    print("\nTriangle with base of", base, "stars:")
    for i in range(1, base + 1):
        print('*' * i)
def draw_rectangle(base):
    height = 3 #can make this user defined too
    print("\nRectangle with a base of", base, "stars:")
    print('*' * base) #top border
    for _ in range(height - 2):
        print('*' * base) #bootom border
#Get user input
base = int(input("Enter the base number stars: "))
#Draw the shapes
draw_triangle(base)
draw_rectangle(base)
