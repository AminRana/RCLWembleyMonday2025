#2. Create a program with two functions – to count/print numbers 1 to 10 and 10 to 1.
#After running the program successfully, make sure you are saving as exercise2.py.
def count_up():
    print("Counting from 1 to 10:")
    for i in range(1, 11):
        print(i, end='')
    print()#For new line
    
def count_down():
    print("Counting from 10 to 1:")
    for i in range(10, 0, -1):
        print(i, end='')
    print()# For new line
    
#Colling the functions
count_up()
count_down()
