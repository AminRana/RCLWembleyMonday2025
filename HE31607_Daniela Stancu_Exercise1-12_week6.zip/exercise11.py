#11. Modify Week 4 Exercise 7 program and make it better using functions.


students = {
    "Mizan": {"IT": 86, "Science": 69},
    "Ram": {"IT": 75, "Science": 46},
    "John": {"IT": 35, "Science": 50},
    "Ann": {"IT": 55, "Science": 76},
    "Chris": {"IT": 45, "Science": 65}
}

def calculate_total(marks):
    return sum(marks.values())

def calculate_average(marks):
    return sum(marks.values()) / len(marks)

def calculate_grade(avg):
    if avg >= 80:
        return 'A'
    elif avg >= 60:
        return 'B'
    elif avg >= 40:
        return 'C'
    else:
        return 'F'

def print_student_totals():
    print("\nStudent Totals:")
    for student, marks in students.items():
        total = calculate_total(marks)
        print(f"{student}: {total}")

def print_student_grades():
    print("\nStudent Grades:")
    for student, marks in students.items():
        avg = calculate_average(marks)
        grade = calculate_grade(avg)
        print(f"{student}: Grade {grade} (Average: {avg:.2f})")

def search_student(name):
    name = name.capitalize()
    if name in students:
        print(f"\n{name}'s marks:")
        for subject, mark in students[name].items():
            print(f"{subject}: {mark}")
        total = calculate_total(students[name])
        avg = calculate_average(students[name])
        grade = calculate_grade(avg)
        print(f"Total: {total}")
        print(f"Average: {avg:.2f}")
        print(f"Grade: {grade}")
    else:
        print(f"Student '{name}' not found.")

def main():
    print_student_totals()
    print_student_grades()
    name = input("\nEnter a student name to search: ").strip()
    search_student(name)

if __name__ == "__main__":
    main()


