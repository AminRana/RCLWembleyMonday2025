#8. Create a program to calculate and print cumulative running after entering each
#number and also ask if user will run the program again or not. If user types yes, it will
#continue and if he types no, it stops. For example, the output can be shown like
#below:
#Type your number: 7
#Your total: 7
#Will you run the program again (yes/no)? yes
#Type your number: 4
#Your total: 11
#Will you run the program again (yes/no)? yes
#Type your number: 2
#Your total: 13
#Will you run the program again (yes/no)? no

def run_cumulative_sum():
    total = 0
    while True:
        try:
            num = int(input("Type your number: "))
            total += num
            print(f"Your total: {total}")
        except ValueError:
            print("Please enter a valid number.")

        repeat = input("Will you run the program again (yes/no)? ").strip().lower()
        if repeat != "yes":
            print("Goodbye!")
            break

# Run the program
run_cumulative_sum()
