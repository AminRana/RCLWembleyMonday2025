#Week 5
#Example 4 – Create a dictionary with some programme names – such as Python, C++, Java, JavaScript, HTML and MySQL.

course={1:{"Python"}, 2:{"C++"}, 3:{"Java"}, 4:{"JavaScript"}, 5:{"HTML"}, 6:{"mySQL"}}

#(a) print all Keys
#print(course.keys())
for k in course.keys():
    print(k)
#(b) Print all Values
#print(course.values())
for v in course.values():
    print(v)
#(c) print all key-value pairs
#print(course.items())
for k,v in course.items():
    print(k, v)
#(d) add a new item into the dictionary
item=input("Type your new course name:").lower()
cid=len(course)
course[cid]=item

#(e) Update a key’s value
course.update({"JavaScript": "JS"})

#(f)print all key-value pairs again
#print(course.items())
for k,v in course.items():
    print(k, v) 

#(g) Delete a key from the dictionary  
course.pop(5)
              
#(h) find value from a key
print(course.get(3))

#(i) search a key
if course.get(3):
    print("Key 3 exists")
else:
    print("Key 3 does not exist")
