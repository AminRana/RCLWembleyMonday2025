Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 7c.py
John 	 40 	 male
Smith 	 24 	 female
Lima 	 30 	 female
Ben 	 45 	 male
Dolly 	 55 	 female
Jolly 	 32 	 female
Bush 	 25 	 male
Zen 	 20 	 female
Lisa 	 60 	 female
Chris 	 28 	 male
