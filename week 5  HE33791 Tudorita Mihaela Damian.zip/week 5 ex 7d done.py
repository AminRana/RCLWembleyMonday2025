Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 7d.py
John 	 40 	 male 	 sales
Smith 	 24 	 female 	 marketing
Lima 	 30 	 female 	 it
Ben 	 45 	 male 	 hr
Dolly 	 55 	 female 	 hr
Jolly 	 32 	 female 	 sales
Bush 	 25 	 male 	 hr
Zen 	 20 	 female 	 it
Lisa 	 60 	 female 	 sales
Chris 	 28 	 male 	 marketing
