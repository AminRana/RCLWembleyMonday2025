Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 8c.py
Name 	 Position 	 Salarygender
Emma 	 Engineer 	 45000
Gray 	 Driver 	 28000
Johnny 	 Tutor 	 38000
Zen 	 Driver 	 25000
Mihaela 	 sales assistant 	 32000
Mihaela 	 sales assistant 	 32000
