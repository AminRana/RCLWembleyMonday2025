Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 2.py =
4D List:
1 ['John', 40, 'male', 'sales']
2 ['Smith', 24, 'female', 'marketing']
3 ['Lima', 30, 'female', 'it']
4 ['Ben', 45, 'male', 'hr']
5 ['Dolly', 55, 'female', 'hr']
6 ['Jolly', 32, 'female', 'sales']
7 ['Bush', 25, 'male', 'hr']
8 ['Zen', 20, 'female', 'it']
9 ['Lisa', 60, 'female', 'sales']
10 ['Chris', 28, 'male', 'marketing']
Type your name to add into list:mihaela
Type your age:37
Type your gender:female
Type your department:sales assistant
1 ['John', 40, 'male', 'sales']
2 ['Smith', 24, 'female', 'marketing']
3 ['Lima', 30, 'female', 'it']
4 ['Ben', 45, 'male', 'hr']
5 ['Dolly', 55, 'female', 'hr']
6 ['Jolly', 32, 'female', 'sales']
7 ['Bush', 25, 'male', 'hr']
8 ['Zen', 20, 'female', 'it']
9 ['Lisa', 60, 'female', 'sales']
10 ['Chris', 28, 'male', 'marketing']
11 ['Mihaela', 37, 'female', 'sales assistant']
