Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 3.py =
1 ['Biscuit', 1.99, 6] 	 11.94
2 ['Oil', 3.99, 12] 	 47.88
3 ['Milk', 2.19, 7] 	 15.33
4 ['Donut', 0.99, 16] 	 15.84
5 ['Bike', 150, 14] 	 2100
6 ['TV', 399, 2] 	 798
7 ['Pie', 0.99, 24] 	 23.76
8 ['Cake', 12.5, 4] 	 50.0
9 ['Book', 5, 4] 	 20
10 ['Mobile', 129, 3] 	 387
Type your item name to add:laptop
Type price of the item:500
Type quantity of the item to add:2
1 ['Biscuit', 1.99, 6] 	 11.94
2 ['Oil', 3.99, 12] 	 47.88
3 ['Milk', 2.19, 7] 	 15.33
4 ['Donut', 0.99, 16] 	 15.84
5 ['Bike', 150, 14] 	 2100
6 ['TV', 399, 2] 	 798
7 ['Pie', 0.99, 24] 	 23.76
8 ['Cake', 12.5, 4] 	 50.0
9 ['Book', 5, 4] 	 20
10 ['Mobile', 129, 3] 	 387
11 ['Laptop', 500.0, 2] 	 1000.0
Total Sales: 4469.75
