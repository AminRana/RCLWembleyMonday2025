Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 7b.py
John 	 40
Smith 	 24
Lima 	 30
Ben 	 45
Dolly 	 55
Jolly 	 32
Bush 	 25
Zen 	 20
Lisa 	 60
Chris 	 28
