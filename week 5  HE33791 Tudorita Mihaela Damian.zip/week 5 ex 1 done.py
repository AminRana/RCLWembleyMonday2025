Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 1.py =
1D List:
John
Smith
Lima
Ben
Dolly
Jolly
Bush
Zen
Lisa
Chris
John
Smith
Lima
Ben
Dolly
Jolly
Bush
Zen
Lisa
Chris
Xu

2D List:
['John', 40]
['Smith', 24]
['Lima', 30]
['Ben', 45]
['Dolly', 55]
['Jolly', 32]
['Bush', 25]
['Zen', 20]
['Lisa', 60]
['Chris', 28]
['John', 40]
['Smith', 24]
['Lima', 30]
['Ben', 45]
['Dolly', 55]
['Jolly', 32]
['Bush', 25]
['Zen', 20]
['Lisa', 60]
['Chris', 28]
['Xu', 32]

3D List:
[['John', 40, 'male'], ['Smith', 24, 'female'], ['Lima', 30, 'female'], ['Ben', 45, 'male'], ['Dolly', 55, 'female'], ['Jolly', 32, 'female'], ['Bush', 25, 'male'], ['Zen', 20, 'female'], ['Lisa', 60, 'female'], ['Chris', 28, 'male']]
[['John', 40, 'male'], ['Smith', 24, 'female'], ['Lima', 30, 'female'], ['Ben', 45, 'male'], ['Dolly', 55, 'female'], ['Jolly', 32, 'female'], ['Bush', 25, 'male'], ['Zen', 20, 'female'], ['Lisa', 60, 'female'], ['Chris', 28, 'male'], ['Xu', 32, 'male']]

4D List:
[['John', 40, 'male', 'sales'], ['Smith', 24, 'female', 'marketing'], ['Lima', 30, 'female', 'it'], ['Ben', 45, 'male', 'hr'], ['Dolly', 55, 'female', 'hr'], ['Jolly', 32, 'female', 'sales'], ['Bush', 25, 'male', 'hr'], ['Zen', 20, 'female', 'it'], ['Lisa', 60, 'female', 'sales'], ['Chris', 28, 'male', 'marketing']]
[['John', 40, 'male', 'sales'], ['Smith', 24, 'female', 'marketing'], ['Lima', 30, 'female', 'it'], ['Ben', 45, 'male', 'hr'], ['Dolly', 55, 'female', 'hr'], ['Jolly', 32, 'female', 'sales'], ['Bush', 25, 'male', 'hr'], ['Zen', 20, 'female', 'it'], ['Lisa', 60, 'female', 'sales'], ['Chris', 28, 'male', 'marketing']]
