Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 5 Examples\Week 5 Example 10.py
1 	 Biscuit 	 1.99 	 6 	 11.94
2 	 Oil 	 3.99 	 12 	 47.88
3 	 Milk 	 2.19 	 7 	 15.33
4 	 Donut 	 0.99 	 16 	 15.84
5 	 Bike 	 150 	 14 	 2100.0
6 	 TV 	 399 	 2 	 798.0
7 	 Pie 	 0.99 	 24 	 23.76
8 	 Cake 	 12.5 	 4 	 50.0
9 	 Book 	 5 	 4 	 20.0
10 	 Mobile 	 129 	 3 	 387.0
11 	 Chair 	 3.99 	 3 	 11.97
12 	 Kk 	 4.0 	 66 	 264.0
13 	 K 	 7.0 	 8 	 56.0
14 	 Mizan 	 0.99 	 5 	 4.95
15 	 Chair 	 9.99 	 10 	 99.9
16 	 Table 	 3.99 	 3 	 11.97
17 	 Bottle 	 4.0 	 2 	 8.0
18 	 Kochu 	 3.99 	 6 	 23.94
19 	 Sofa 	 200.0 	 5 	 1000.0
Type a new item:bread
Type price of the new item:1.99
Type quantity of the new item:5
Total sales: 4960.43
