Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 10 - Examples\skeleton of example 1.py

1. Display Results
2. Add Student's results
3. Search result by name
4. Update Student's grade
5. Delete a Student
6. Quit
Type your choice between 1 and 6:6
