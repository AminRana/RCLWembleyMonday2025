Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
=== RESTART: C:\Users\mihae\OneDrive\Desktop\Week 10 - Examples\example 1a.py ==

1. Display Results
2. Add Student's results
3. Search result by name
4. Update Student's grade
5. Delete a Student
6. Quit
Type your choice netween 1 and 6:3
Type a student name to search:John
The student John  is found in the system

1. Display Results
2. Add Student's results
3. Search result by name
4. Update Student's grade
5. Delete a Student
6. Quit
Type your choice netween 1 and 6:1
['John', 45, 'Pass']
['Raya', 65, 'Merit']
['Bob', 76, 'Distinction']
['Boby', 38, 'Fail']
['Chris', 66, 'Merit']
['Dili', 70, 'Merit']
['Gaby', 58, 'Pass']
['Ali', 74, 'Merit']
['Anne', 80, 'Distinction']
['Jack', 50, 'Pass']

1. Display Results
2. Add Student's results
3. Search result by name
4. Update Student's grade
5. Delete a Student
6. Quit
Type your choice netween 1 and 6:6
