while True:
    user_salary = input("Enter your yearly gross salary: ")
    
    gross_salary = float(user_salary)

    if gross_salary <= 12570:
            tax = 0
    elif gross_salary <= 50270:
            tax = (gross_salary - 12570) * 0.20
    elif gross_salary <= 125140:
            tax = (gross_salary - 50270) * 0.40
    else:
            tax = (gross_salary - 125140) * 0.45

    net_salary = gross_salary - tax

    print("Gross Salary: £" + str(gross_salary))
    print("Tax: £" + str(tax))
    print("Net Salary: £" + str(net_salary))

