#Write a program to display a menu option. Then it will ask you to type a number between 1 and 4. If 1, 2, 3 and 4 are typed, the program
#displays "Added", "Searched", "Updated" and "Deleted" messages respectively. The menu option looks like
#1. Add
#2. Search
#3. Update
#4. Delete
print("Menu Options:")
print("1. Add")
print("2. Search")
print("3. Update")
print("4. Delete")
while True: #Added a loop so used can select more then one option  
    user_input = input("What option whould you like to do: ")

    if user_input == "1":
        print("Added")
    elif user_input == "2":
        print("Searched")
    elif user_input == "3":
        print("Updated")
    elif user_input == "4":
        print("Deleted")
    
       
       