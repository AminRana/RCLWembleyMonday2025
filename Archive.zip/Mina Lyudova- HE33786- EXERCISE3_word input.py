while True:
    user_word = input("Enter a word: ")
    
    length = len(user_word)
    
    if 1 <= length <= 3:
        print("too short word")
    elif 4 <= length <= 8:
        print("small word")
    elif 9 <= length <= 12:
        print("big word")
    elif length > 12:
        print("too big word")
    
       
