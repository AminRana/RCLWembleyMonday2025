#Write a program to display hourly rate for 4 different professions. The program will ask user to type a profession and then display the hourly
#rate of the profession.
#The hourly rate of teacher, doctor, lawyer and driver is £25, £60, £200 and £15 respectively

print("Select a profession from the list below:")
print("1. Teacher")
print("2. Doctor")
print("3. Lawyer")
print("4. Driver")

while True: #Added a loop so user can select more than one option

    choice = input("Enter a number 1–4 for chosen profession: ")

    if choice == "1":
        print("TEACHER → The hourly rate for a teacher is £25.")
    elif choice == "2":
        print("DOCTOR → The hourly rate for a doctor is £60.")
    elif choice == "3":
        print("LAWYER → The hourly rate for a lawyer is £200.")
    elif choice == "4":
        print("DRIVER → The hourly rate for a driver is £15.")
    
    