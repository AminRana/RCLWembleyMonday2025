#Exercise 2: Store " regent college London " into col string variable like below and
#answer the questions and/or write syntax for questions (a) to (f)
#col= " regent college London "
#a) Remove leading and trailing whitespaces from string col and store it as a new string, col2
#b) Convert lowercase of col2
#c) Convert title case of col2
#d) Convert upper case of col2
#e) Find college word into col2
#f) Replace college by university into col2
#g)Check col2 isalpha() to see it is a string of characters or not

while True: #Added a loop so user can check the marks for more than one student
    mark_input = input("Enter the student's mark: ")
    
    # The mark_input needs to be a valid number.
    #If not- remind the user with a meesage 
    if not mark_input.isdigit():
        print("Please enter a valid number.")
        continue
    
    stuMark = int(mark_input) 
    #I have add a little face experrions to the grade output 
    if stuMark > 74:
        grade = "Distinction (:D)"
    elif 60 <= stuMark <= 74:
        grade = "Merit :)"
    elif 40 <= stuMark <= 59:
        grade = "Pass :/"
    elif 0 <= stuMark <= 39:
        grade = "Fail ;("
    
    print("Grade:", grade)
