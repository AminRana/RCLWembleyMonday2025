# Given col=regent collage London
col = " regent college London "

# a) Remove leading and trailing whitespaces and store as col2
col2 = col.strip()
print("col2=", col2)

# b) Convert to lowercase col2
col_lower = col2.lower()
print("lowercase of col2:", col_lower)

# c) Convert to title case
col_title = col2.title()
print("Title Case:", col_title)

# d) Convert all to uppercase
col_upper = col2.upper()
print("All Uppercase:", col_upper)

# e) Find the word "college"
college_name = col2.find("college")
print("Find 'college' word:", college_name)

# f) Replace "college" with "university"
col_replace = col2.replace("college", "university")
print("Replace collage to university:", col_replace)

# g) Check if the string contains only letters (no spaces)
is_alpha_true = col2.isalpha()
print("Is alphabetic only:", is_alpha_true)
