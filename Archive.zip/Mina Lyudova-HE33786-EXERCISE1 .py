mystring = "Regent College London"

# print inder 0 to 6
print(mystring[0:7])  

# print index 0, 7 and 15 
print(mystring[0] + mystring[7] + mystring[15])  

# print "College" 
print(mystring[7:14])  

# print "gentle" 
letters = (mystring[2] + mystring[3] + mystring[4] + mystring[5])
print(letters+"le")  

# print last 3 characters (don)
print(mystring[-3] + mystring[-2] + mystring[-1]) 

# print only "Regent London"
print(mystring[0:7] + mystring[15:21])  

