#Exercise 1: Store "Regent College London" into col string variable like below and answer the questions and/or write
#syntax for questions (a) to (f)
#col= "Regent College London"

col="Regent College london"
print(col[0:7])
print("index 0:",col[0])
print("index 7:",col[7])
print("index 15:",col[15])
print(col[2:7])
print(col[10:12])
print(col[2:6]+col[10:12])
print(col[-3:])
print(col[0:7]+col[7:14])


