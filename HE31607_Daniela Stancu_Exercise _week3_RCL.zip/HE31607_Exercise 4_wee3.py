#4a) On Exercise 3a, you have written a program to calculate grades. Modify this program to check first whether the
#given input mark is within the range of 0 and 100 using an outer if statement. If the input mark is within the range,
#then the inner if-else statement will calculate and display correct grades only.

mark = int(input("Enter your mark (0-100): "))
if 0 <= mark <= 100:
    if mark >= 70:
        print("Grade: A")
    elif mark >= 60:
        print("Grade: B")
    elif mark >= 50:
        print("Grade: C")
    elif mark >= 40:
        print("Grade: D")
    else:
        print("Grade: F")
else:
    print("Invalid mark. Please enter a value between 0 and 100.")



#4b) Write a program to add two input numbers. The program will first check whether the inputs are characters or
#integer numbers using outer if statement. If both inputs are number, then the program will add them up and check
#total is less or more than 100.
input1 = input("Enter first number: ")
input2 = input("Enter second number: ")
if input1.isdigit() and input2.isdigit():
    num1 = int(input1)
    num2 = int(input2)
    total = num1 + num2
    print(f"Total:{total}")
    if total < 100:
        print("The total is less than 100.")
    else:
        print("The total is 100 or more.")
else:
    print("invalid input. Please enter numbers only.")


#4c) Modify Exercise 3c to check first whether the user input is between 1 and 4 or not (creating an outer if
#statement) and if input within range, then put rest codes (what you have done for 3c) under inner if statement.

choice = int(input("Enter a number between 1 and 4: "))
if 1 <= choice <= 4:
    if choice == 1:
        print("You chose option 1")
    elif choice == 2:
        print("You chose option 2")
    elif choice == 3:
        print("You chose option 3")
    elif choice == 4:
        print("You chose option 4")
else:
    print("Invalid input. Please enter a number between 1 and 4. ")
        
#4d) Write a program to generate a random number between 1 and 5, then ask user to type his guess and compare
#his guess with generated random number. If the guess is correct, then repeat the process (generate random
#number, ask user to type his guess and compare them), otherwise, stop the program.

import random
while True:
    random_number = random.randint(1, 5)
    guess = int(input("Guess the number (1-5): "))
    if guess == random_number:
        print("Correct! Try again.")
    else:
        print(f"Wrong! The number was {random_number}. Game over.")


#4e)Write a program to calculate odd/even number from a given number. After taking an input from the user, the
#program first will check whether it is within the range of 100 or not. If it is within the range of 100, it will calculate
#odd or even number only. The program will display messages correctly

number = int(input("Enter a number (0-100): "))
if 0 <= number <= 100:
    if number % 2 == 0:
        print(f"{number} is even. ")
    else:
        print(f"{number} is odd. ")
else:
    print("Invalid number. Please enter a number between 0 and 100. ")
