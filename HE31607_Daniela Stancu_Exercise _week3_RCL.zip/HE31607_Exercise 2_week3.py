#Exercise 2: Store " regent college London " into col string variable like below and
#answer the questions and/or write syntax for questions (a) to (f)
#col= " regent college London "

col=" regent college London "
print(col.strip())
print(col.replace("col","col2"))
col2="regent college London"
print(col2.lower())
print(col2.title())
print(col2.upper())
print(col2.find("college"))
print(col2.replace("college","university"))
print(col2.isalpha())
