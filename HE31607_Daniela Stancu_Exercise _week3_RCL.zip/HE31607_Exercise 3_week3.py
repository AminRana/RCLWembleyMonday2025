#3a) Write a program to calculate and print a student's grade based on given input mark. If mark is above 74, grade is Distinction. If mark is
#between 60 and 74, then grade is Merit. If mark is between 40 and 59, then grade is Pass. If mark is between 0 and 39, then grade is Fail.

marks=int(input("enter your marks(0 to 100)\n"))
if marks>=74:
    grade="Distinction"
elif marks>=60:
     grade="Merit"
elif marks>=40:
      grade="Pass"
elif marks>=0:
    grade="Fail"
else:
    grade="invalid mark"
print("Grade:", grade)

#3b Write a program to calculate the number of characters from a user's string input. If the number of characters is between 1 and 3, between 4
#and 8, between 9 and 12, and more than 12 then display results "too short word", "small word", "big word" and "too big word" respectively.


user_input = input("Enter a word: ")
length = len(user_input)

if 1 <= length <= 3:
    print("too short word")
elif 4 <= length <= 8:
    print("small word")
elif 9 <= length <= 12:
    print("big word")
elif length > 12:
    print("too big word")
else:
    print("No word entered")
#3c) Write a program to display a menu option. Then it will ask you to type a number between 1 and 4. If 1, 2, 3 and 4 are typed, the program
#displays "Added", "Searched", "Updated" and "Deleted" messages respectively. The menu option looks like
#1. Add
#2. Search
#3. Update
#4. Delete

def menu():
    print("[1] Add")
    print("[2] Search")
    print("[3] Update")
    print("[4] Delete")

menu()
option = int(input("Enter your option between 1 to 4:"))
if option ==1:
        #do option 1
        print("Added")
elif option ==2:
        #do option 2
        print("Searched")
elif option ==3:
        #do option 3
        print("Updated")
elif option ==4:
        #do option 4
        print("Deleted")
else:

        print("Invalid option.")

print()
menu()
option = int(input("Enter your option: "))

#3d Write a program to display hourly rate for 4 different professions. The program will ask user to type a profession and then display the hourly
#rate of the profession. The hourly rate of teacher, doctor, lawyer and driver is £25, £60, £200 and £15 respectively.

hourly_rates = {"teacher":25, "doctor":60, "lawyer": 200, "driver":15}
profession = input("Enter a profession (teacher, doctor, lawyer, driver): ").strip().lower()
if profession in hourly_rates:
    print(f"The hourly rate for a {profession} is £{hourly_rates[profession]}")
else:
    print("Sorry, the profession is not recognised.")

#3e) Write a program to calculate yearly tax and net salary from the input of a yearly gross salary. For the program, yearly tax rate is given below:
#Up to £12,570 no tax is required
#Between £12,571 and £50,270 20% tax
#Between £50,271 and £125,140 40% tax
#Above £125,141 45% tax
    

def calculate_tax(gross_salary):
    tax = 0

    if gross_salary > 125140:
        tax += (gross_salary - 125140) * 0.45
        gross_salary = 125140

    if gross_salary > 50270:
        tax += (gross_salary - 50270) * 0.40
        gross_salary = 50270

    if gross_salary > 12570:
        tax += (gross_salary - 12570) * 0.20

    net_salary = gross_salary + (gross_salary - 12570) * 0.20 if gross_salary > 12570 else gross_salary
    net_salary = gross_salary - tax

    return tax, net_salary

# Input from user
gross_salary = float(input("Enter your yearly gross salary (£): "))
tax, net_salary = calculate_tax(gross_salary)

print(f"Yearly Tax: £{tax:.2f}")
print(f"Net Salary after Tax: £{net_salary:.2f}")

