Python 3.13.4 (tags/v3.13.4:8a526ec, Jun  3 2025, 17:46:04) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
= RESTART: C:\Users\mihae\OneDrive\Desktop\Week 4 Examples\Week 4 Example 7.py =
Type number of rows:6
Type number of columns:3
 £ ££ 
 £ ££ 
 £ ££ 
 $ $$ 
 $ $$ 
 $ $$ 
