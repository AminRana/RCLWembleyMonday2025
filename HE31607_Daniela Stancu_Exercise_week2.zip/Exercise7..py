#7. Name and Age Comparison
name1 = input("Type your name: ")
age1 = int(input("Type your age: "))

name2 = input("Type your friend's name: ")
age2 = int(input("Type your friend's age: "))

print(f"{name1}'s age is {age1}")
print(f"{name2}'s age is {age2}")
