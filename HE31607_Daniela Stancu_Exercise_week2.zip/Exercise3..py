#3.Simple Interest Calculation

capital = float(input("Type amount of your capital: "))
rate = float(input("Type yearly interest rate: "))
years = float(input("Type number of years: "))

interest = (capital * rate * years) / 100

print("Total interest:", round(interest, 2))
