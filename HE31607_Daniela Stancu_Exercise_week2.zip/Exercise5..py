#5.Power of a Number

base = int(input("Type any number or base: "))
power = int(input("Type any integer number as power: "))

result = base ** power

print(f"{base} to the power of {power} is {result}")
