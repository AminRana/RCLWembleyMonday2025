#1.Add and Multtiply Two Numbers

num1 = float(input("Type 1st number: "))
num2 = float(input("Type 2nd number: "))

total = num1 + num2
product = num1 * num2

print("Total of two numbers:", total)
print("Multiplication of two numbers:", product)
