#6.Remainder of Division
dividend = int(input("Type any number as dividend: "))
divisor = int(input("Type any number as divisor: "))

remainder = dividend % divisor

print(f"{remainder} is the remainder dividing {dividend} by {divisor}")
