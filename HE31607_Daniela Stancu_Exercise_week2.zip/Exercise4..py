#4.Convert Age in Years to Days
name = input("Type your name: ")
age = float(input("Type your age in years: "))

days = int(age * 365.25)  # including leap years

print(f"{name}'s is {days} days old")
