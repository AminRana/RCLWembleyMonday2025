#2.Volume of a Cylinder
import math

radius = float(input("Type radius of the cylinder: "))
height = float(input("Type height of the cylinder: "))

volume = math.pi * radius ** 2 * height

print("The volume of the cylinder: {:.2f}".format(volume))
